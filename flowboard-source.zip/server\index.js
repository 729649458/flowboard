import http from 'node:http';
import { Server } from 'socket.io';
import { createApp } from './app.js';
import { migrate, DATA_DIR } from './db.js';
import { seed } from './seed.js';
import { attachRealtime } from './realtime.js';

migrate();
const created = seed();
if (created) console.log('📦 已生成示例数据（4 位成员 / 3 个项目 / 28 个任务）');

const app = createApp();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: true },
  maxHttpBufferSize: 1e6,
});
app.set('io', io);
attachRealtime(io);

const PORT = Number(process.env.PORT || 5174);
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 FlowBoard server  http://localhost:${PORT}`);
  console.log(`   data dir: ${DATA_DIR}`);
});

const shutdown = () => {
  console.log('\n👋 正在关闭服务...');
  io.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
