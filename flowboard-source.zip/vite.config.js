import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': 'http://127.0.0.1:5174',
      '/uploads': 'http://127.0.0.1:5174',
      '/socket.io': { target: 'http://127.0.0.1:5174', ws: true },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
