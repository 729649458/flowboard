import { db, get, run, uid, migrate } from './db.js';
import { hashPassword } from './auth.js';
import { pathToFileURL } from 'node:url';

const now = Date.now();
const iso = (msAgo = 0) => new Date(now - msAgo).toISOString();
const days = (n) => n * 86400000;
const dateOnly = (offsetDays) =>
  new Date(now + offsetDays * 86400000).toISOString().slice(0, 10);

const USERS = [
  {
    id: 'u_chen',
    name: '张金鹏',
    email: '729649458@qq.com',
    title: '产品负责人',
    role: 'admin',
    color: '#6366f1',
  },
  { id: 'u_lin', name: '林晓', email: 'lin@flowboard.dev', title: '前端工程师', role: 'member', color: '#ec4899' },
  { id: 'u_su', name: '苏晚', email: 'su@flowboard.dev', title: 'UI 设计师', role: 'member', color: '#f59e0b' },
  { id: 'u_zhou', name: '周铭', email: 'zhou@flowboard.dev', title: '后端工程师', role: 'member', color: '#10b981' },
];

const LABELS = [
  ['需求', '#6366f1'],
  ['前端', '#ec4899'],
  ['后端', '#10b981'],
  ['设计', '#f59e0b'],
  ['性能', '#0ea5e9'],
  ['Bug', '#ef4444'],
];

const PROJECTS = [
  {
    id: 'p_flow',
    name: 'FlowBoard 2.0 产品迭代',
    key: 'FB',
    color: '#4f46e5',
    owner: 'u_chen',
    description: '面向 10 人以下敏捷团队的新一代协作看板，覆盖需求、开发、验收全流程。',
    tasks: [
      ['完成需求评审并输出 PRD v1.2', 'completed', 'high', 'u_chen', ['需求'], -9, 2],
      ['看板拖拽交互重构（支持跨列排序）', 'doing', 'high', 'u_lin', ['前端'], 3, 5],
      ['任务详情抽屉的信息架构优化', 'review', 'medium', 'u_su', ['设计', '需求'], 1, 3],
      ['接入 Socket.IO 实时同步', 'doing', 'high', 'u_zhou', ['后端'], 2, 4],
      ['列表页 1 万条任务虚拟滚动性能压测', 'todo', 'medium', 'u_lin', ['性能'], 8, 2],
      ['登录页视觉稿与品牌插画', 'completed', 'medium', 'u_su', ['设计'], -6, 1],
      ['成员权限模型设计（Owner / Admin / Member）', 'review', 'high', 'u_zhou', ['后端'], 0, 3],
      ['通知中心聚合规则梳理', 'todo', 'low', 'u_chen', ['需求'], 12, 1],
      ['修复 Safari 下拖拽残影问题', 'todo', 'urgent', 'u_lin', ['Bug', '前端'], -1, 0],
      ['数据看板：任务完成趋势图', 'doing', 'medium', 'u_lin', ['前端', '设计'], 6, 2],
      ['为任务卡片增加优先级色带', 'completed', 'low', 'u_su', ['设计', '前端'], -3, 0],
      ['编写 API 文档与 Postman 集合', 'todo', 'medium', 'u_zhou', ['后端'], 9, 0],
    ],
  },
  {
    id: 'p_web',
    name: '品牌官网视觉升级',
    key: 'WEB',
    color: '#db2777',
    owner: 'u_su',
    description: '重塑品牌调性，完成官网首页、产品页与案例页的视觉升级和性能优化。',
    tasks: [
      ['首页品牌主张文案定稿', 'completed', 'medium', 'u_chen', ['需求'], -8, 1],
      ['主视觉 3D 渲染图', 'doing', 'high', 'u_su', ['设计'], 4, 4],
      ['响应式断点与栅格规范', 'review', 'medium', 'u_su', ['设计'], 2, 2],
      ['首屏 LCP 优化到 1.8s 以内', 'todo', 'high', 'u_lin', ['性能', '前端'], 7, 3],
      ['接入内容管理后台', 'todo', 'medium', 'u_zhou', ['后端'], 15, 2],
      ['埋点方案与事件字典', 'doing', 'low', 'u_chen', ['需求'], 10, 1],
      ['案例页滚动动效实现', 'doing', 'medium', 'u_lin', ['前端'], 5, 2],
    ],
  },
  {
    id: 'p_data',
    name: '数据洞察中台',
    key: 'DATA',
    color: '#0891b2',
    owner: 'u_zhou',
    description: '统一指标口径，建设实时数据看板与告警体系，为业务决策提供数据支撑。',
    tasks: [
      ['数仓分层规范（ODS / DWD / DWS）', 'completed', 'high', 'u_zhou', ['后端'], -12, 2],
      ['指标口径对齐会议纪要', 'review', 'medium', 'u_chen', ['需求'], 0, 1],
      ['实时看板 WebSocket 推送', 'doing', 'high', 'u_zhou', ['后端'], 3, 3],
      ['数据质量监控与告警', 'todo', 'high', 'u_zhou', ['后端'], 11, 2],
      ['图表主题适配暗色模式', 'todo', 'low', 'u_lin', ['前端', '设计'], 14, 1],
      ['按部门隔离数据权限', 'doing', 'medium', 'u_zhou', ['后端'], 6, 2],
      ['导出 Excel 报表', 'todo', 'low', 'u_lin', ['前端'], 18, 1],
      ['慢查询优化（P95 < 300ms）', 'todo', 'medium', 'u_zhou', ['性能', '后端'], 9, 0],
      ['核心指标卡片组件', 'completed', 'medium', 'u_lin', ['前端'], -5, 1],
    ],
  },
];

const DESCRIPTIONS = {
  default:
    '拆解目标、明确验收标准，并在每日站会同步进展。完成后请补充验证记录，便于后续复盘。',
  '看板拖拽交互重构（支持跨列排序）':
    '当前拖拽仅支持同列排序，且松手后存在 200ms 闪烁。计划引入指针事件 + FLIP 动画，支持跨列拖拽与实时占位预览。',
  '接入 Socket.IO 实时同步':
    '多端同时编辑时需要即时看到任务变更。方案：按项目划分 room，服务端广播 task.* 事件，客户端做乐观更新与冲突回滚。',
  '成员权限模型设计（Owner / Admin / Member）':
    'Owner 可删除项目，Admin 可管理成员与流程，Member 仅可编辑自己创建或被指派的任务。需要补充接口层校验与前端隐藏逻辑。',
  '修复 Safari 下拖拽残影问题':
    'Safari 17 在 dragstart 后未清除 transform，导致残影。排查是否与 will-change 和 backdrop-filter 组合有关。',
  '任务详情抽屉的信息架构优化':
    '将「描述 / 检查项 / 评论 / 附件」重新分组，减少首屏信息密度，把低频字段收进「更多属性」。',
  '首屏 LCP 优化到 1.8s 以内':
    '压缩主视觉资源，改为 AVIF + 响应式尺寸，关键 CSS 内联，字体使用 font-display: swap。',
};

const COMMENTS = [
  '我这边已经把接口草案放到文档里了，字段命名大家看一下有没有歧义。',
  '设计稿更新到 v3，主要调整了卡片间距和空状态插画，链接见附件。',
  '复现了，只在 iOS Safari 出现，怀疑是 transform 与 will-change 的组合问题。',
  '建议先做最小可用版本，把实时同步的范围收敛到任务与评论两类事件。',
  '验收标准补充：需要覆盖 1440 / 1024 / 768 三个断点，并且键盘可操作。',
];

function reset() {
  db.exec('PRAGMA foreign_keys = OFF;');
  for (const t of [
    'activities',
    'notifications',
    'attachments',
    'checklist_items',
    'comments',
    'task_labels',
    'tasks',
    'labels',
    'columns',
    'project_members',
    'projects',
    'users',
  ]) {
    try {
      run(`DELETE FROM ${t}`);
    } catch {
      /* ignore */
    }
  }
  db.exec('PRAGMA foreign_keys = ON;');
}

export function seed({ force = false } = {}) {
  migrate();
  const count = get('SELECT COUNT(*) AS c FROM users').c;
  if (count > 0 && !force) return false;

  db.exec('BEGIN');
  try {
    reset();
    const pw = hashPassword('demo1234');

    for (const u of USERS) {
      run(
        `INSERT INTO users (id, name, email, password_hash, avatar_color, title, role, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        u.id,
        u.name,
        u.email,
        pw,
        u.color,
        u.title,
        u.role,
        iso(days(40))
      );
    }

    const columnsByProject = {};
    const labelsByProject = {};
    let taskSeq = 0;

    for (const p of PROJECTS) {
      run(
        `INSERT INTO projects (id, name, key, description, color, owner_id, archived, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
        p.id,
        p.name,
        p.key,
        p.description,
        p.color,
        p.owner,
        iso(days(20))
      );

      const memberIds = new Set([p.owner, ...p.tasks.map((t) => t[3])]);
      for (const uid_ of memberIds) {
        run(
          `INSERT INTO project_members (project_id, user_id, role, joined_at) VALUES (?, ?, ?, ?)`,
          p.id,
          uid_,
          uid_ === p.owner ? 'owner' : 'member',
          iso(days(18))
        );
      }

      const cols = [
        ['todo', '待办', 0, null],
        ['doing', '进行中', 1, 5],
        ['review', '待评审', 2, 3],
        ['completed', '已完成', 3, null],
      ];
      columnsByProject[p.id] = {};
      for (const [key, name, position, wip] of cols) {
        const cid = `c_${p.id.slice(2)}_${key}`;
        columnsByProject[p.id][key] = cid;
        run(
          `INSERT INTO columns (id, project_id, name, position, wip_limit) VALUES (?, ?, ?, ?, ?)`,
          cid,
          p.id,
          name,
          position,
          wip
        );
      }

      labelsByProject[p.id] = {};
      LABELS.forEach(([name, color], i) => {
        const lid = `l_${p.id.slice(2)}_${i}`;
        labelsByProject[p.id][name] = lid;
        run(
          `INSERT INTO labels (id, project_id, name, color) VALUES (?, ?, ?, ?)`,
          lid,
          p.id,
          name,
          color
        );
      });

      const posByCol = {};
      p.tasks.forEach(([title, colKey, priority, assignee, labels, dueOffset, commentCount], idx) => {
        const tid = `t_${p.id.slice(2)}_${String(idx + 1).padStart(2, '0')}`;
        const colId = columnsByProject[p.id][colKey];
        posByCol[colId] = (posByCol[colId] ?? 0) + 1;
        const createdAgo = days(14 - Math.min(13, idx));
        const completed = colKey === 'completed';
        run(
          `INSERT INTO tasks
             (id, project_id, column_id, title, description, priority, assignee_id, reporter_id,
              due_date, position, created_at, updated_at, completed_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          tid,
          p.id,
          colId,
          title,
          DESCRIPTIONS[title] || DESCRIPTIONS.default,
          priority,
          assignee,
          p.owner,
          dateOnly(dueOffset),
          posByCol[colId] * 1.0,
          iso(createdAgo),
          iso(createdAgo - days(1)),
          completed ? iso(Math.max(days(1), createdAgo - days(2))) : null
        );

        for (const l of labels) {
          if (labelsByProject[p.id][l]) {
            run(
              `INSERT OR IGNORE INTO task_labels (task_id, label_id) VALUES (?, ?)`,
              tid,
              labelsByProject[p.id][l]
            );
          }
        }

        if (idx % 4 !== 3) {
          const items = ['补充接口文档与字段说明', '完成自测并回填结果', '邀请相关同学评审'];
          items.forEach((text, k) => {
            run(
              `INSERT INTO checklist_items (id, task_id, text, done, position) VALUES (?, ?, ?, ?, ?)`,
              uid('ck_'),
              tid,
              text,
              completed || (idx % 2 === 0 && k === 0) ? 1 : 0,
              k
            );
          });
        }

        for (let k = 0; k < commentCount; k++) {
          const commenter = USERS[(idx + k + 1) % USERS.length];
          const body = COMMENTS[(idx + k) % COMMENTS.length];
          const at = iso(Math.max(days(0.2), createdAgo - days(k + 0.5)));
          run(
            `INSERT INTO comments (id, task_id, user_id, body, created_at) VALUES (?, ?, ?, ?, ?)`,
            uid('cm_'),
            tid,
            commenter.id,
            body,
            at
          );
          run(
            `INSERT INTO activities (id, project_id, task_id, user_id, action, detail, created_at)
             VALUES (?, ?, ?, ?, 'comment.created', ?, ?)`,
            uid('ac_'),
            p.id,
            tid,
            commenter.id,
            body.slice(0, 60),
            at
          );
        }

        if (colKey === 'doing' && idx % 3 === 1) {
          run(
            `INSERT INTO activities (id, project_id, task_id, user_id, action, detail, created_at)
             VALUES (?, ?, ?, ?, 'task.moved', ?, ?)`,
            uid('ac_'),
            p.id,
            tid,
            assignee,
            `${title} → 进行中`,
            iso(Math.max(days(0.4), createdAgo - days(1.2)))
          );
        }

        const creator = USERS[(idx + 3) % USERS.length].id;
        run(
          `INSERT INTO activities (id, project_id, task_id, user_id, action, detail, created_at)
           VALUES (?, ?, ?, ?, 'task.created', ?, ?)`,
          uid('ac_'),
          p.id,
          tid,
          creator,
          title,
          iso(createdAgo)
        );

        if (completed) {
          run(
            `INSERT INTO activities (id, project_id, task_id, user_id, action, detail, created_at)
             VALUES (?, ?, ?, ?, 'task.completed', ?, ?)`,
            uid('ac_'),
            p.id,
            tid,
            assignee,
            title,
            iso(Math.max(days(0.5), createdAgo - days(2)))
          );
        }

        taskSeq++;
      });
    }

    // 示例通知：面向 demo 账号 张金鹏
    const notifs = [
      ['mention', '林晓 在评论中 @ 了你', '看板拖拽交互重构（支持跨列排序）', 'p_flow', 't_flow_02', 0, 0.3],
      ['assign', '周铭 将任务指派给你', '成员权限模型设计（Owner / Admin / Member）', 'p_flow', 't_flow_07', 0, 2],
      ['comment', '苏晚 评论了任务', '任务详情抽屉的信息架构优化', 'p_flow', 't_flow_03', 0, 5],
      ['system', '每日站会提醒', '今天 10:00 · 线上会议室 A', 'p_flow', null, 1, 9],
      ['status', '任务已完成', '登录页视觉稿与品牌插画', 'p_web', 't_web_06', 1, 26],
    ];
    for (const [type, title, body, projectId, taskId, read, hoursAgo] of notifs) {
      run(
        `INSERT INTO notifications (id, user_id, type, title, body, project_id, task_id, read, created_at)
         VALUES (?, 'u_chen', ?, ?, ?, ?, ?, ?, ?)`,
        uid('nt_'),
        type,
        title,
        body,
        projectId,
        taskId,
        read,
        iso(hoursAgo * 3600000)
      );
    }

    db.exec('COMMIT');
    return true;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const changed = seed({ force: process.argv.includes('--force') });
  console.log(changed ? '✅ 示例数据已写入 data/flowboard.db' : 'ℹ️ 数据库已有数据，跳过（--force 可重置）');
}
