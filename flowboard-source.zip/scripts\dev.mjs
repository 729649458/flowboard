import { spawn } from 'node:child_process';
import path from 'node:path';

const node = process.execPath;
const root = process.cwd();
const children = [];

function run(label, args) {
  const child = spawn(node, args, {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, FORCE_COLOR: '1' },
  });
  child.on('exit', (code) => {
    console.log(`[${label}] exited with ${code}`);
    shutdown(code ?? 0);
  });
  children.push(child);
}

function shutdown(code) {
  for (const c of children) {
    if (!c.killed) c.kill();
  }
  process.exit(code);
}

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));

run('server', ['--watch', 'server/index.js']);
run('client', [path.join('node_modules', 'vite', 'bin', 'vite.js')]);
