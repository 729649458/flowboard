﻿# 一键打包实习提交材料
# 用法：
#   .\scripts\package-submission.ps1 -Class "软件2201班" -StudentId "20220001" -Name "张三" `
#       -VideoPath "D:\录屏\demo.mp4" -NodesDir "D:\考核节点截图"

param(
  [Parameter(Mandatory = $true)][string]$Class,
  [Parameter(Mandatory = $true)][string]$StudentId,
  [Parameter(Mandatory = $true)][string]$Name,
  [string]$VideoPath = '',
  [string]$NodesDir = '',
  [string]$ReportPath = 'docs\2220232674_张金鹏_软件工程二班_实习报告.docx'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$base = "$Class$StudentId$Name"
$outRoot = Join-Path $root '提交材料'
$stage = Join-Path $outRoot $base
$zipPath = Join-Path $outRoot "$base.zip"

Write-Host "==> 目标：$base" -ForegroundColor Cyan

if (-not (Test-Path $ReportPath)) {
  throw "未找到实习报告：$ReportPath ，请先生成报告。"
}

# 1. 清理旧目录
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
New-Item -ItemType Directory -Force $stage | Out-Null

# 2. 实习报告
Copy-Item $ReportPath (Join-Path $stage "$base.docx")
Write-Host "  [1/5] 实习报告 -> $base.docx"

# 3. 项目截图
$shotDir = Join-Path $stage '项目截图'
New-Item -ItemType Directory -Force $shotDir | Out-Null
$shots = [ordered]@{
  'login.png'     = '01-登录页.png'
  'workbench.png' = '02-工作台.png'
  'board.png'     = '03-看板.png'
  'task.png'      = '04-任务详情.png'
  'dashboard.png' = '05-数据洞察.png'
  'board-dark.png'= '06-深色主题.png'
  'activity.png'  = '07-项目动态.png'
}
foreach ($k in $shots.Keys) {
  $src = Join-Path $root "screenshots\$k"
  if (Test-Path $src) { Copy-Item $src (Join-Path $shotDir $shots[$k]) }
}
Write-Host "  [2/5] 项目截图 -> $(Get-ChildItem $shotDir | Measure-Object | Select-Object -ExpandProperty Count) 张"

# 4. 前 5 个考核节点
$nodeOut = Join-Path $stage '前5个考核节点'
New-Item -ItemType Directory -Force $nodeOut | Out-Null
if ($NodesDir -and (Test-Path $NodesDir)) {
  $nodeFiles = Get-ChildItem $NodesDir -File | Sort-Object Name | Select-Object -First 5
  $i = 1
  foreach ($f in $nodeFiles) {
    Copy-Item $f.FullName (Join-Path $nodeOut ("{0:D2}-考核节点{1}" -f $i, $f.Extension))
    $i++
  }
  Write-Host "  [3/5] 考核节点 -> $($nodeFiles.Count) 张"
} else {
  @'
请将前 5 次考核的截图放入本文件夹，并按 01-05 命名。
若已按 01-考核节点.png ... 05-考核节点.png 命名，可直接删除本说明。
'@ | Set-Content (Join-Path $nodeOut '说明.txt') -Encoding UTF8
  Write-Host "  [3/5] 考核节点 -> 占位（请放入 5 张截图）" -ForegroundColor Yellow
}

# 5. 视频
$videoOut = Join-Path $stage '视频'
New-Item -ItemType Directory -Force $videoOut | Out-Null
if ($VideoPath -and (Test-Path $VideoPath)) {
  Copy-Item $VideoPath (Join-Path $videoOut "$base.mp4")
  Write-Host "  [4/5] 视频 -> $base.mp4"
} else {
  @'
请将录屏文件命名为「班级+学号+姓名.mp4」并放入本文件夹。
推荐分辨率 1920x1080，时长 5-8 分钟，演示前先展示部署平台与域名。
'@ | Set-Content (Join-Path $videoOut '请放入录屏视频.txt') -Encoding UTF8
  Write-Host "  [4/5] 视频 -> 占位（请放入 mp4）" -ForegroundColor Yellow
}

# 6. 源码
$srcOut = Join-Path $stage '项目源码'
New-Item -ItemType Directory -Force $srcOut | Out-Null
$excludeDirs = @('node_modules', 'data', 'dist', '.git', '.shots', '提交材料', '.pnpm-store', 'screenshots', 'installers', 'tools', 'pdf_text', '.dsh-*')
$excludeFiles = @('*.log', '参考-*.docx')
$robocopyArgs = @(
  $root, $srcOut, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP',
  '/XD'
) + $excludeDirs + @('/XF') + $excludeFiles
& robocopy @robocopyArgs | Out-Null
if ($LASTEXITCODE -ge 8) { throw "复制源码失败（robocopy exit $LASTEXITCODE）" }
Write-Host "  [5/5] 源码 -> $(Get-ChildItem $srcOut | Measure-Object | Select-Object -ExpandProperty Count) 个顶层条目"

# 7. 提交说明
@"
FlowBoard · 实习项目提交材料
班级：$Class
学号：$StudentId
姓名：$Name

项目方向：全栈项目（前端 + 后端 + 数据库）
技术栈：React 18 / Vite / Node.js / Express / SQLite / Socket.IO
部署平台：Render（填写实际平台）
在线地址：https://（填写实际域名）
演示账号：chen@flowboard.dev / demo1234

包含内容：
1. 实习报告（$base.docx）
2. 前 5 个考核节点截图
3. 项目截图 7 张
4. 演示视频
5. 项目源码
"@ | Set-Content (Join-Path $stage '提交说明.txt') -Encoding UTF8

# 8. 压缩
Compress-Archive -Path $stage -DestinationPath $zipPath -CompressionLevel Optimal
$size = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)

Write-Host ""
Write-Host "✅ 打包完成" -ForegroundColor Green
Write-Host "   目录：$stage"
Write-Host "   压缩包：$zipPath（$size MB）"
Write-Host "   请检查压缩包内是否只有一层同名文件夹，再发送至 976134036@qq.com"
