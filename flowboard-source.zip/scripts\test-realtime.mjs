import { io } from 'socket.io-client';

const base = process.env.BASE_URL || 'http://127.0.0.1:5174';

const json = (res) => res.json();
const login = await fetch(`${base}/api/auth/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'chen@flowboard.dev', password: 'demo1234' }),
}).then(json);
if (!login.token) throw new Error('登录失败');

const socket = io(base, { auth: { token: login.token }, transports: ['websocket'] });
await new Promise((resolve, reject) => {
  socket.on('connect', resolve);
  socket.on('connect_error', reject);
  setTimeout(() => reject(new Error('socket connect timeout')), 5000);
});

socket.emit('project:join', 'p_flow');
await new Promise((r) => setTimeout(r, 300));

const board = await fetch(`${base}/api/projects/p_flow/board`, {
  headers: { Authorization: `Bearer ${login.token}` },
}).then(json);
const columnId = board.columns[0].id;

const eventPromise = new Promise((resolve, reject) => {
  socket.on('task:created', resolve);
  setTimeout(() => reject(new Error('未收到 task:created 事件')), 5000);
});

const created = await fetch(`${base}/api/projects/p_flow/tasks`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${login.token}` },
  body: JSON.stringify({ title: '实时同步冒烟测试', columnId }),
}).then(json);

const evt = await eventPromise;
console.log('✅ 实时事件到达:', evt.task.title);

await fetch(`${base}/api/tasks/${created.task.id}`, {
  method: 'DELETE',
  headers: { Authorization: `Bearer ${login.token}` },
});
socket.close();
console.log('✅ 清理完成，实时链路正常');
