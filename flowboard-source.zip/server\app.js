import express from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import { all, get, run, uid, UPLOAD_DIR, ROOT } from './db.js';
import {
  hashPassword,
  verifyPassword,
  signToken,
  publicUser,
  requireAuth,
  isMember,
} from './auth.js';

const COLORS = ['#6366f1', '#ec4899', '#f59e0b', '#10b981', '#0ea5e9', '#8b5cf6', '#ef4444'];
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const brief = (u) =>
  u ? { id: u.id, name: u.name, title: u.title, avatarColor: u.avatar_color } : null;

const projectOfTask = (taskId) =>
  get(
    `SELECT t.*, p.id AS p_id FROM tasks t JOIN projects p ON p.id = t.project_id WHERE t.id = ?`,
    taskId
  );

function memberRows(projectId) {
  return all(
    `SELECT u.*, pm.role AS project_role, pm.joined_at
       FROM project_members pm JOIN users u ON u.id = pm.user_id
      WHERE pm.project_id = ?
      ORDER BY pm.joined_at ASC`,
    projectId
  ).map((u) => ({ ...brief(u), projectRole: u.project_role }));
}

function logActivity(projectId, taskId, userId, action, detail) {
  run(
    `INSERT INTO activities (id, project_id, task_id, user_id, action, detail, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    uid('ac_'),
    projectId,
    taskId,
    userId,
    action,
    detail,
    new Date().toISOString()
  );
}

function notify(io, userId, payload) {
  if (!userId) return;
  const row = {
    id: uid('nt_'),
    user_id: userId,
    type: payload.type || 'info',
    title: payload.title,
    body: payload.body || '',
    project_id: payload.projectId || null,
    task_id: payload.taskId || null,
    read: 0,
    created_at: new Date().toISOString(),
  };
  run(
    `INSERT INTO notifications (id, user_id, type, title, body, project_id, task_id, read, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
    row.id,
    row.user_id,
    row.type,
    row.title,
    row.body,
    row.project_id,
    row.task_id,
    row.created_at
  );
  io?.to(`user:${userId}`).emit('notification', {
    id: row.id,
    type: row.type,
    title: row.title,
    body: row.body,
    projectId: row.project_id,
    taskId: row.task_id,
    read: false,
    createdAt: row.created_at,
  });
}

function mapTask(t, labels = [], counts = {}) {
  return {
    id: t.id,
    projectId: t.project_id,
    columnId: t.column_id,
    title: t.title,
    description: t.description,
    priority: t.priority,
    assigneeId: t.assignee_id,
    reporterId: t.reporter_id,
    dueDate: t.due_date,
    position: t.position,
    createdAt: t.created_at,
    updatedAt: t.updated_at,
    completedAt: t.completed_at,
    labels,
    checklist: { total: counts.total ?? 0, done: counts.done ?? 0 },
    commentCount: counts.comments ?? 0,
    attachmentCount: counts.attachments ?? 0,
  };
}

const TASK_COUNTS = `
  (SELECT COUNT(*) FROM checklist_items ci WHERE ci.task_id = t.id) AS ck_total,
  (SELECT COUNT(*) FROM checklist_items ci WHERE ci.task_id = t.id AND ci.done = 1) AS ck_done,
  (SELECT COUNT(*) FROM comments c WHERE c.task_id = t.id) AS ck_comments,
  (SELECT COUNT(*) FROM attachments a WHERE a.task_id = t.id) AS ck_attachments
`;

function taskWithLabels(taskId) {
  const t = get(`SELECT t.*, ${TASK_COUNTS} FROM tasks t WHERE t.id = ?`, taskId);
  if (!t) return null;
  const labels = all(
    `SELECT l.id, l.name, l.color FROM task_labels tl JOIN labels l ON l.id = tl.label_id WHERE tl.task_id = ?`,
    taskId
  );
  return mapTask(t, labels, {
    total: t.ck_total,
    done: t.ck_done,
    comments: t.ck_comments,
    attachments: t.ck_attachments,
  });
}

function fullTask(taskId) {
  const t = get(`SELECT t.*, ${TASK_COUNTS} FROM tasks t WHERE t.id = ?`, taskId);
  if (!t) return null;
  const labels = all(
    `SELECT l.id, l.name, l.color FROM task_labels tl JOIN labels l ON l.id = tl.label_id WHERE tl.task_id = ?`,
    taskId
  );
  const comments = all(
    `SELECT c.*, u.name, u.avatar_color, u.title FROM comments c JOIN users u ON u.id = c.user_id
      WHERE c.task_id = ? ORDER BY c.created_at ASC`,
    taskId
  ).map((c) => ({
    id: c.id,
    body: c.body,
    createdAt: c.created_at,
    user: { id: c.user_id, name: c.name, avatarColor: c.avatar_color, title: c.title },
  }));
  const checklist = all(
    'SELECT * FROM checklist_items WHERE task_id = ? ORDER BY position ASC, id ASC',
    taskId
  ).map((c) => ({ id: c.id, text: c.text, done: !!c.done }));
  const attachments = all(
    'SELECT * FROM attachments WHERE task_id = ? ORDER BY created_at ASC',
    taskId
  ).map((a) => ({
    id: a.id,
    name: a.original_name,
    size: a.size,
    mime: a.mime,
    createdAt: a.created_at,
    url: `/api/attachments/${a.id}/download`,
  }));
  return {
    ...mapTask(t, labels, {
      total: t.ck_total,
      done: t.ck_done,
      comments: t.ck_comments,
      attachments: t.ck_attachments,
    }),
    assignee: brief(get('SELECT * FROM users WHERE id = ?', t.assignee_id)),
    reporter: brief(get('SELECT * FROM users WHERE id = ?', t.reporter_id)),
    comments,
    checklist,
    attachments,
  };
}

function boardPayload(projectId) {
  const project = get('SELECT * FROM projects WHERE id = ?', projectId);
  const columns = all('SELECT * FROM columns WHERE project_id = ? ORDER BY position ASC', projectId);
  const tasks = all(
    `SELECT t.*, ${TASK_COUNTS} FROM tasks t WHERE t.project_id = ? ORDER BY t.position ASC, t.created_at ASC`,
    projectId
  );
  const labels = all('SELECT * FROM labels WHERE project_id = ? ORDER BY name ASC', projectId);
  const labelRows = all(
    `SELECT tl.task_id, l.id, l.name, l.color
       FROM task_labels tl JOIN labels l ON l.id = tl.label_id WHERE l.project_id = ?`,
    projectId
  );
  const byTask = new Map();
  for (const row of labelRows) {
    if (!byTask.has(row.task_id)) byTask.set(row.task_id, []);
    byTask.get(row.task_id).push({ id: row.id, name: row.name, color: row.color });
  }
  const mapped = tasks.map((t) =>
    mapTask(t, byTask.get(t.id) || [], {
      total: t.ck_total,
      done: t.ck_done,
      comments: t.ck_comments,
      attachments: t.ck_attachments,
    })
  );
  return {
    project: { ...project, memberCount: memberRows(projectId).length },
    columns: columns.map((c) => ({
      id: c.id,
      name: c.name,
      position: c.position,
      wipLimit: c.wip_limit,
      tasks: mapped.filter((t) => t.columnId === c.id),
    })),
    members: memberRows(projectId),
    labels,
  };
}

function requireProjectMember(req, res, projectId) {
  if (!isMember(projectId, req.user.id)) {
    res.status(403).json({ error: '你不是该项目的成员' });
    return false;
  }
  return true;
}

export function createApp() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  });

  const upload = multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
      filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname).slice(0, 12).replace(/[^\w.]/g, '');
        cb(null, uid('f_') + ext.toLowerCase());
      },
    }),
    limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  });

  // ---------------- 认证 ----------------
  app.post(
    '/api/auth/register',
    wrap((req, res) => {
      const name = String(req.body.name || '').trim();
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');
      if (name.length < 2 || name.length > 24) return res.status(400).json({ error: '昵称需为 2-24 个字符' });
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: '邮箱格式不正确' });
      if (password.length < 6) return res.status(400).json({ error: '密码至少 6 位' });
      if (get('SELECT 1 AS ok FROM users WHERE email = ?', email)) {
        return res.status(409).json({ error: '该邮箱已注册，请直接登录' });
      }
      const id = uid('u_');
      run(
        `INSERT INTO users (id, name, email, password_hash, avatar_color, title, role, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'member', ?)`,
        id,
        name,
        email,
        hashPassword(password),
        COLORS[Math.floor(Math.random() * COLORS.length)],
        '新成员',
        new Date().toISOString()
      );
      const user = get('SELECT * FROM users WHERE id = ?', id);
      res.status(201).json({ token: signToken(user), user: publicUser(user) });
    })
  );

  app.post(
    '/api/auth/login',
    wrap((req, res) => {
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');
      const user = get('SELECT * FROM users WHERE email = ?', email);
      if (!user || !verifyPassword(password, user.password_hash)) {
        return res.status(401).json({ error: '邮箱或密码不正确' });
      }
      res.json({ token: signToken(user), user: publicUser(user) });
    })
  );

  app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

  app.get(
    '/api/users',
    requireAuth,
    wrap((_req, res) => {
      res.json({ users: all('SELECT * FROM users ORDER BY created_at ASC').map(brief) });
    })
  );

  // ---------------- 项目 ----------------
  app.get(
    '/api/projects',
    requireAuth,
    wrap((req, res) => {
      const rows = all(
        `SELECT p.*, u.name AS owner_name, u.avatar_color AS owner_color,
                (SELECT COUNT(*) FROM project_members pm2 WHERE pm2.project_id = p.id) AS member_count,
                (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count,
                (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.completed_at IS NOT NULL) AS done_count
           FROM projects p
           JOIN users u ON u.id = p.owner_id
           JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = ?
          WHERE p.archived = 0
          ORDER BY p.created_at DESC`,
        req.user.id
      );
      res.json({
        projects: rows.map((p) => ({
          id: p.id,
          name: p.name,
          key: p.key,
          description: p.description,
          color: p.color,
          ownerId: p.owner_id,
          owner: { id: p.owner_id, name: p.owner_name, avatarColor: p.owner_color },
          memberCount: p.member_count,
          taskCount: p.task_count,
          doneCount: p.done_count,
          members: all(
            `SELECT u.id, u.name, u.title, u.avatar_color FROM project_members pm
               JOIN users u ON u.id = pm.user_id WHERE pm.project_id = ? LIMIT 4`,
            p.id
          ).map(brief),
          createdAt: p.created_at,
        })),
      });
    })
  );

  app.post(
    '/api/projects',
    requireAuth,
    wrap((req, res) => {
      const name = String(req.body.name || '').trim();
      if (name.length < 2 || name.length > 40) return res.status(400).json({ error: '项目名称需为 2-40 个字符' });
      const key = (String(req.body.key || name.slice(0, 2)).replace(/[^a-zA-Z0-9]/g, '').toUpperCase() || 'PRJ').slice(0, 6);
      const id = uid('p_');
      const now = new Date().toISOString();
      const color = /^#[0-9a-fA-F]{6}$/.test(req.body.color || '') ? req.body.color : COLORS[0];
      run(
        `INSERT INTO projects (id, name, key, description, color, owner_id, archived, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
        id,
        name,
        key,
        String(req.body.description || '').slice(0, 500),
        color,
        req.user.id,
        now
      );
      run(
        `INSERT INTO project_members (project_id, user_id, role, joined_at) VALUES (?, ?, 'owner', ?)`,
        id,
        req.user.id,
        now
      );
      ['待办', '进行中', '待评审', '已完成'].forEach((n, i) =>
        run(
          'INSERT INTO columns (id, project_id, name, position, wip_limit) VALUES (?, ?, ?, ?, ?)',
          uid('c_'),
          id,
          n,
          i,
          i === 1 ? 5 : i === 2 ? 3 : null
        )
      );
      [
        ['需求', '#6366f1'],
        ['设计', '#f59e0b'],
        ['前端', '#ec4899'],
        ['后端', '#10b981'],
        ['Bug', '#ef4444'],
      ].forEach(([n, c]) =>
        run('INSERT INTO labels (id, project_id, name, color) VALUES (?, ?, ?, ?)', uid('l_'), id, n, c)
      );
      logActivity(id, null, req.user.id, 'project.created', name);
      res.status(201).json({ project: get('SELECT * FROM projects WHERE id = ?', id) });
    })
  );

  app.get(
    '/api/projects/:id',
    requireAuth,
    wrap((req, res) => {
      if (!requireProjectMember(req, res, req.params.id)) return;
      const p = get('SELECT * FROM projects WHERE id = ?', req.params.id);
      res.json({
        project: p,
        members: memberRows(p.id),
        columns: all('SELECT * FROM columns WHERE project_id = ? ORDER BY position ASC', p.id),
        labels: all('SELECT * FROM labels WHERE project_id = ? ORDER BY name ASC', p.id),
      });
    })
  );

  app.patch(
    '/api/projects/:id',
    requireAuth,
    wrap((req, res) => {
      if (!requireProjectMember(req, res, req.params.id)) return;
      const p = get('SELECT * FROM projects WHERE id = ?', req.params.id);
      const name = req.body.name !== undefined ? String(req.body.name).trim() : p.name;
      if (name.length < 2) return res.status(400).json({ error: '项目名称过短' });
      run(
        'UPDATE projects SET name = ?, description = ?, color = ? WHERE id = ?',
        name,
        req.body.description !== undefined ? String(req.body.description).slice(0, 500) : p.description,
        /^#[0-9a-fA-F]{6}$/.test(req.body.color || '') ? req.body.color : p.color,
        p.id
      );
      logActivity(p.id, null, req.user.id, 'project.updated', name);
      res.json({ ok: true });
    })
  );

  app.delete(
    '/api/projects/:id',
    requireAuth,
    wrap((req, res) => {
      const p = get('SELECT * FROM projects WHERE id = ?', req.params.id);
      if (!p) return res.status(404).json({ error: '项目不存在' });
      if (p.owner_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ error: '只有项目所有者可以删除项目' });
      }
      run('DELETE FROM projects WHERE id = ?', p.id);
      res.json({ ok: true });
    })
  );

  app.post(
    '/api/projects/:id/members',
    requireAuth,
    wrap((req, res) => {
      const p = get('SELECT * FROM projects WHERE id = ?', req.params.id);
      if (!p) return res.status(404).json({ error: '项目不存在' });
      if (!requireProjectMember(req, res, p.id)) return;
      const email = String(req.body.email || '').trim().toLowerCase();
      const user = get('SELECT * FROM users WHERE email = ?', email);
      if (!user) return res.status(404).json({ error: '未找到该邮箱对应的用户' });
      if (isMember(p.id, user.id)) return res.status(409).json({ error: '该成员已在项目中' });
      run(
        `INSERT INTO project_members (project_id, user_id, role, joined_at) VALUES (?, ?, 'member', ?)`,
        p.id,
        user.id,
        new Date().toISOString()
      );
      logActivity(p.id, null, req.user.id, 'member.added', user.name);
      notify(req.app.get('io'), user.id, {
        type: 'invite',
        title: `你被邀请加入「${p.name}」`,
        body: `${req.user.name} 邀请你加入项目协作`,
        projectId: p.id,
      });
      res.status(201).json({ member: brief(user) });
    })
  );

  app.delete(
    '/api/projects/:id/members/:userId',
    requireAuth,
    wrap((req, res) => {
      const p = get('SELECT * FROM projects WHERE id = ?', req.params.id);
      if (!p) return res.status(404).json({ error: '项目不存在' });
      if (p.owner_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ error: '只有项目所有者可以移除成员' });
      }
      if (req.params.userId === p.owner_id) return res.status(400).json({ error: '不能移除项目所有者' });
      run('DELETE FROM project_members WHERE project_id = ? AND user_id = ?', p.id, req.params.userId);
      res.json({ ok: true });
    })
  );

  app.get(
    '/api/projects/:id/board',
    requireAuth,
    wrap((req, res) => {
      if (!requireProjectMember(req, res, req.params.id)) return;
      res.json(boardPayload(req.params.id));
    })
  );

  app.get(
    '/api/projects/:id/stats',
    requireAuth,
    wrap((req, res) => {
      const projectId = req.params.id;
      if (!requireProjectMember(req, res, projectId)) return;
      const tasks = all('SELECT * FROM tasks WHERE project_id = ?', projectId);
      const members = memberRows(projectId);
      const done = tasks.filter((t) => t.completed_at);
      const today = new Date().toISOString().slice(0, 10);
      const overdue = tasks.filter((t) => !t.completed_at && t.due_date && t.due_date < today);
      const trend = [];
      for (let i = 13; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000);
        const key = d.toISOString().slice(0, 10);
        trend.push({
          date: key,
          label: `${d.getMonth() + 1}/${d.getDate()}`,
          count: done.filter((t) => (t.completed_at || '').slice(0, 10) === key).length,
        });
      }
      const byPriority = { urgent: 0, high: 0, medium: 0, low: 0 };
      tasks.forEach((t) => {
        byPriority[t.priority] = (byPriority[t.priority] || 0) + 1;
      });
      const workload = members.map((m) => {
        const mine = tasks.filter((t) => t.assignee_id === m.id);
        return {
          ...m,
          total: mine.length,
          done: mine.filter((t) => t.completed_at).length,
          active: mine.filter((t) => !t.completed_at).length,
        };
      });
      const cycles = done
        .map((t) => (new Date(t.completed_at) - new Date(t.created_at)) / 86400000)
        .filter((n) => Number.isFinite(n) && n >= 0);
      res.json({
        totals: {
          total: tasks.length,
          done: done.length,
          active: tasks.length - done.length,
          overdue: overdue.length,
          completionRate: tasks.length ? Math.round((done.length / tasks.length) * 100) : 0,
          avgCycleDays: cycles.length
            ? Math.round((cycles.reduce((a, b) => a + b, 0) / cycles.length) * 10) / 10
            : 0,
        },
        trend,
        byPriority,
        workload,
      });
    })
  );

  app.get(
    '/api/projects/:id/activity',
    requireAuth,
    wrap((req, res) => {
      if (!requireProjectMember(req, res, req.params.id)) return;
      const rows = all(
        `SELECT a.*, u.name, u.avatar_color FROM activities a LEFT JOIN users u ON u.id = a.user_id
          WHERE a.project_id = ? ORDER BY a.created_at DESC LIMIT 30`,
        req.params.id
      );
      res.json({
        activities: rows.map((a) => ({
          id: a.id,
          action: a.action,
          detail: a.detail,
          taskId: a.task_id,
          createdAt: a.created_at,
          user: a.user_id ? { id: a.user_id, name: a.name, avatarColor: a.avatar_color } : null,
        })),
      });
    })
  );

  // ---------------- 任务 ----------------
  app.post(
    '/api/projects/:id/tasks',
    requireAuth,
    wrap((req, res) => {
      const projectId = req.params.id;
      if (!requireProjectMember(req, res, projectId)) return;
      const title = String(req.body.title || '').trim();
      if (!title) return res.status(400).json({ error: '任务标题不能为空' });
      if (title.length > 120) return res.status(400).json({ error: '任务标题不能超过 120 字' });
      const columns = all('SELECT * FROM columns WHERE project_id = ? ORDER BY position ASC', projectId);
      const columnId = req.body.columnId || columns[0]?.id;
      const col = columns.find((c) => c.id === columnId);
      if (!col) return res.status(400).json({ error: '列表不存在' });
      const assigneeId = req.body.assigneeId && get('SELECT 1 AS ok FROM users WHERE id = ?', req.body.assigneeId)
        ? req.body.assigneeId
        : null;
      const priority = ['urgent', 'high', 'medium', 'low'].includes(req.body.priority)
        ? req.body.priority
        : 'medium';
      const pos = get('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM tasks WHERE column_id = ?', columnId).p;
      const id = uid('t_');
      const nowISO = new Date().toISOString();
      run(
        `INSERT INTO tasks (id, project_id, column_id, title, description, priority, assignee_id, reporter_id,
                            due_date, position, created_at, updated_at, completed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`,
        id,
        projectId,
        columnId,
        title,
        String(req.body.description || '').slice(0, 4000),
        priority,
        assigneeId,
        req.user.id,
        req.body.dueDate || null,
        pos,
        nowISO,
        nowISO
      );
      if (Array.isArray(req.body.labelIds)) {
        for (const labelId of req.body.labelIds.slice(0, 8)) {
          if (get('SELECT 1 AS ok FROM labels WHERE id = ? AND project_id = ?', labelId, projectId)) {
            run('INSERT OR IGNORE INTO task_labels (task_id, label_id) VALUES (?, ?)', id, labelId);
          }
        }
      }
      logActivity(projectId, id, req.user.id, 'task.created', title);
      if (assigneeId && assigneeId !== req.user.id) {
        notify(req.app.get('io'), assigneeId, {
          type: 'assign',
          title: `${req.user.name} 给你指派了任务`,
          body: title,
          projectId,
          taskId: id,
        });
      }
      const task = taskWithLabels(id);
      req.app.get('io')?.to(`project:${projectId}`).emit('task:created', { task, by: req.user.id });
      res.status(201).json({ task });
    })
  );

  app.get(
    '/api/tasks/:id',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) return;
      res.json({ task: fullTask(req.params.id) });
    })
  );

  app.patch(
    '/api/tasks/:id',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) return;
      const projectId = task.project_id;
      const b = req.body;
      const title = b.title !== undefined ? String(b.title).trim() : task.title;
      if (!title) return res.status(400).json({ error: '任务标题不能为空' });
      const assigneeId =
        b.assigneeId !== undefined
          ? b.assigneeId && get('SELECT 1 AS ok FROM users WHERE id = ?', b.assigneeId)
            ? b.assigneeId
            : null
          : task.assignee_id;
      const priority = ['urgent', 'high', 'medium', 'low'].includes(b.priority) ? b.priority : task.priority;
      const description = b.description !== undefined ? String(b.description).slice(0, 4000) : task.description;
      const dueDate = b.dueDate !== undefined ? b.dueDate || null : task.due_date;
      run(
        `UPDATE tasks SET title = ?, description = ?, priority = ?, assignee_id = ?, due_date = ?, updated_at = ?
          WHERE id = ?`,
        title,
        description,
        priority,
        assigneeId,
        dueDate,
        new Date().toISOString(),
        task.id
      );
      if (Array.isArray(b.labelIds)) {
        run('DELETE FROM task_labels WHERE task_id = ?', task.id);
        for (const labelId of b.labelIds.slice(0, 8)) {
          if (get('SELECT 1 AS ok FROM labels WHERE id = ? AND project_id = ?', labelId, projectId)) {
            run('INSERT OR IGNORE INTO task_labels (task_id, label_id) VALUES (?, ?)', task.id, labelId);
          }
        }
      }
      logActivity(projectId, task.id, req.user.id, 'task.updated', title);
      if (assigneeId && assigneeId !== task.assignee_id && assigneeId !== req.user.id) {
        notify(req.app.get('io'), assigneeId, {
          type: 'assign',
          title: `${req.user.name} 将任务指派给你`,
          body: title,
          projectId,
          taskId: task.id,
        });
      }
      const updated = taskWithLabels(task.id);
      req.app.get('io')?.to(`project:${projectId}`).emit('task:updated', { task: updated, by: req.user.id });
      res.json({ task: updated });
    })
  );

  app.post(
    '/api/tasks/:id/move',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      const projectId = task.project_id;
      if (!requireProjectMember(req, res, projectId)) return;
      const columns = all('SELECT * FROM columns WHERE project_id = ? ORDER BY position ASC', projectId);
      const target = columns.find((c) => c.id === req.body.columnId);
      if (!target) return res.status(400).json({ error: '目标列表不存在' });

      const inTarget = all(
        'SELECT id FROM tasks WHERE column_id = ? AND id != ? ORDER BY position ASC, created_at ASC',
        target.id,
        task.id
      ).map((r) => r.id);
      const index = Math.max(0, Math.min(Number(req.body.index ?? inTarget.length), inTarget.length));
      inTarget.splice(index, 0, task.id);
      inTarget.forEach((id, i) => {
        run('UPDATE tasks SET column_id = ?, position = ? WHERE id = ?', target.id, i, id);
      });
      const completedAt = target.name === '已完成' ? task.completed_at || new Date().toISOString() : null;
      run(
        'UPDATE tasks SET completed_at = ?, updated_at = ? WHERE id = ?',
        completedAt,
        new Date().toISOString(),
        task.id
      );
      if (task.column_id !== target.id) {
        logActivity(projectId, task.id, req.user.id, 'task.moved', `${task.title} → ${target.name}`);
      }
      req.app.get('io')?.to(`project:${projectId}`).emit('board:refresh', { projectId, by: req.user.id });
      res.json({ task: taskWithLabels(task.id) });
    })
  );

  app.delete(
    '/api/tasks/:id',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) return;
      run('DELETE FROM tasks WHERE id = ?', task.id);
      logActivity(task.project_id, null, req.user.id, 'task.deleted', task.title);
      req.app.get('io')?.to(`project:${task.project_id}`).emit('board:refresh', {
        projectId: task.project_id,
        by: req.user.id,
      });
      res.json({ ok: true });
    })
  );

  app.post(
    '/api/tasks/:id/comments',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) return;
      const body = String(req.body.body || '').trim();
      if (!body) return res.status(400).json({ error: '评论内容不能为空' });
      if (body.length > 2000) return res.status(400).json({ error: '评论不能超过 2000 字' });
      const id = uid('cm_');
      const createdAt = new Date().toISOString();
      run(
        'INSERT INTO comments (id, task_id, user_id, body, created_at) VALUES (?, ?, ?, ?, ?)',
        id,
        task.id,
        req.user.id,
        body,
        createdAt
      );
      logActivity(task.project_id, task.id, req.user.id, 'comment.created', body.slice(0, 80));
      const targets = new Set([task.assignee_id, task.reporter_id]);
      targets.delete(req.user.id);
      for (const uid_ of targets) {
        if (!uid_) continue;
        notify(req.app.get('io'), uid_, {
          type: 'comment',
          title: `${req.user.name} 评论了任务`,
          body: `${task.title}：${body.slice(0, 60)}`,
          projectId: task.project_id,
          taskId: task.id,
        });
      }
      const comment = {
        id,
        body,
        createdAt,
        user: brief(req.user),
      };
      req.app.get('io')?.to(`project:${task.project_id}`).emit('comment:created', {
        taskId: task.id,
        comment,
        by: req.user.id,
      });
      res.status(201).json({ comment });
    })
  );

  app.delete(
    '/api/comments/:id',
    requireAuth,
    wrap((req, res) => {
      const c = get('SELECT * FROM comments WHERE id = ?', req.params.id);
      if (!c) return res.status(404).json({ error: '评论不存在' });
      const task = projectOfTask(c.task_id);
      if (!requireProjectMember(req, res, task.project_id)) return;
      if (c.user_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ error: '只能删除自己的评论' });
      }
      run('DELETE FROM comments WHERE id = ?', c.id);
      req.app.get('io')?.to(`project:${task.project_id}`).emit('board:refresh', {
        projectId: task.project_id,
        by: req.user.id,
      });
      res.json({ ok: true });
    })
  );

  app.post(
    '/api/tasks/:id/checklist',
    requireAuth,
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) return;
      const text = String(req.body.text || '').trim();
      if (!text) return res.status(400).json({ error: '检查项内容不能为空' });
      const pos = get('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM checklist_items WHERE task_id = ?', task.id).p;
      run(
        'INSERT INTO checklist_items (id, task_id, text, done, position) VALUES (?, ?, ?, 0, ?)',
        uid('ck_'),
        task.id,
        text.slice(0, 200),
        pos
      );
      res.json({ task: fullTask(task.id) });
    })
  );

  app.patch(
    '/api/checklist/:id',
    requireAuth,
    wrap((req, res) => {
      const item = get('SELECT * FROM checklist_items WHERE id = ?', req.params.id);
      if (!item) return res.status(404).json({ error: '检查项不存在' });
      const task = projectOfTask(item.task_id);
      if (!requireProjectMember(req, res, task.project_id)) return;
      run(
        'UPDATE checklist_items SET done = ?, text = ? WHERE id = ?',
        req.body.done ? 1 : 0,
        req.body.text !== undefined ? String(req.body.text).slice(0, 200) : item.text,
        item.id
      );
      res.json({ task: fullTask(task.id) });
    })
  );

  app.delete(
    '/api/checklist/:id',
    requireAuth,
    wrap((req, res) => {
      const item = get('SELECT * FROM checklist_items WHERE id = ?', req.params.id);
      if (!item) return res.status(404).json({ error: '检查项不存在' });
      const task = projectOfTask(item.task_id);
      if (!requireProjectMember(req, res, task.project_id)) return;
      run('DELETE FROM checklist_items WHERE id = ?', item.id);
      res.json({ task: fullTask(task.id) });
    })
  );

  // ---------------- 附件 ----------------
  app.post(
    '/api/tasks/:id/attachments',
    requireAuth,
    upload.single('file'),
    wrap((req, res) => {
      const task = projectOfTask(req.params.id);
      if (!task) return res.status(404).json({ error: '任务不存在' });
      if (!requireProjectMember(req, res, task.project_id)) {
        if (req.file) fs.unlinkSync(req.file.path);
        return;
      }
      if (!req.file) return res.status(400).json({ error: '未接收到文件' });
      const id = uid('at_');
      run(
        `INSERT INTO attachments (id, task_id, filename, original_name, size, mime, uploaded_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        id,
        task.id,
        req.file.filename,
        req.file.originalname,
        req.file.size,
        req.file.mimetype,
        req.user.id,
        new Date().toISOString()
      );
      const attachment = {
        id,
        name: req.file.originalname,
        size: req.file.size,
        mime: req.file.mimetype,
        createdAt: new Date().toISOString(),
        url: `/api/attachments/${id}/download`,
      };
      req.app.get('io')?.to(`project:${task.project_id}`).emit('board:refresh', {
        projectId: task.project_id,
        by: req.user.id,
      });
      res.status(201).json({ attachment });
    })
  );

  app.get(
    '/api/attachments/:id/download',
    requireAuth,
    wrap((req, res) => {
      const a = get('SELECT * FROM attachments WHERE id = ?', req.params.id);
      if (!a) return res.status(404).json({ error: '附件不存在' });
      const task = projectOfTask(a.task_id);
      if (!requireProjectMember(req, res, task.project_id)) return;
      const file = path.join(UPLOAD_DIR, a.filename);
      if (!fs.existsSync(file)) return res.status(410).json({ error: '文件已丢失' });
      res.download(file, a.original_name);
    })
  );

  // ---------------- 通知 / 搜索 ----------------
  app.get(
    '/api/notifications',
    requireAuth,
    wrap((req, res) => {
      const rows = all(
        'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 40',
        req.user.id
      );
      res.json({
        notifications: rows.map((n) => ({
          id: n.id,
          type: n.type,
          title: n.title,
          body: n.body,
          projectId: n.project_id,
          taskId: n.task_id,
          read: !!n.read,
          createdAt: n.created_at,
        })),
        unread: get('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND read = 0', req.user.id).c,
      });
    })
  );

  app.post(
    '/api/notifications/read',
    requireAuth,
    wrap((req, res) => {
      if (Array.isArray(req.body.ids) && req.body.ids.length) {
        for (const id of req.body.ids.slice(0, 100)) {
          run('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', id, req.user.id);
        }
      } else {
        run('UPDATE notifications SET read = 1 WHERE user_id = ?', req.user.id);
      }
      res.json({ ok: true });
    })
  );

  app.get(
    '/api/search',
    requireAuth,
    wrap((req, res) => {
      const q = String(req.query.q || '').trim();
      if (!q) return res.json({ projects: [], tasks: [] });
      const like = `%${q.replace(/[%_]/g, '')}%`;
      const projects = all(
        `SELECT DISTINCT p.* FROM projects p JOIN project_members pm ON pm.project_id = p.id
          WHERE pm.user_id = ? AND (p.name LIKE ? OR p.description LIKE ?) LIMIT 5`,
        req.user.id,
        like,
        like
      ).map((p) => ({ id: p.id, name: p.name, key: p.key, color: p.color }));
      const tasks = all(
        `SELECT t.*, p.name AS project_name, p.color AS project_color
           FROM tasks t
           JOIN projects p ON p.id = t.project_id
           JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = ?
          WHERE t.title LIKE ? OR t.description LIKE ?
          ORDER BY t.updated_at DESC LIMIT 8`,
        req.user.id,
        like,
        like
      ).map((t) => ({
        id: t.id,
        title: t.title,
        projectId: t.project_id,
        projectName: t.project_name,
        projectColor: t.project_color,
        priority: t.priority,
        columnId: t.column_id,
      }));
      res.json({ projects, tasks });
    })
  );

  app.get('/api/health', (_req, res) => res.json({ ok: true, uptime: process.uptime() }));

  // ---------------- 静态资源 / SPA ----------------
  const dist = path.join(ROOT, 'dist');
  if (fs.existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist, { maxAge: '7d', index: false }));
    app.get(/^\/(?!api\/|uploads\/|socket\.io\/).*/, (_req, res) => {
      res.sendFile(path.join(dist, 'index.html'));
    });
  }

  app.use((req, res) => res.status(404).json({ error: '接口不存在' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    console.error('[api error]', err);
    if (err?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: '文件不能超过 10MB' });
    res.status(500).json({ error: '服务器内部错误' });
  });

  return app;
}
