# FlowBoard · 团队协作项目管理平台

面向 10 人以下敏捷团队的**实时协作看板**：把需求、任务、评审与交付放在同一条河流里。支持多项目、成员协作、拖拽流转、任务评论与附件、实时同步、交付数据洞察，以及浅色 / 深色双主题。

> 全栈实习项目：React 18 + Express + SQLite + Socket.IO，单仓部署，一条命令即可运行。

![看板](screenshots/board.png)

## 功能特性

**项目管理**

- 多项目工作台：项目卡片展示进度、成员与完成率
- 项目成员邀请与移除，Owner / Member 角色区分
- 项目级看板、数据洞察、项目动态三个视图

**看板与任务**

- 四列看板（待办 / 进行中 / 待评审 / 已完成），HTML5 拖拽跨列流转与排序
- WIP 限制提示、优先级色带、标签、截止日期、逾期高亮
- 任务详情抽屉：描述、检查项、评论、附件上传/下载、指派、状态、优先级、标签
- 任务筛选与「只看我的」、全局搜索（项目 / 任务）

**实时协作**

- Socket.IO 按项目分房间，任务变更、评论、动态即时广播
- 在线成员头像与人数实时展示
- 站内通知：指派、评论、邀请，支持全部已读

**数据洞察**

- 任务总数、完成率、平均周期、逾期数
- 近 14 天完成趋势（SVG 面积图）
- 优先级分布环形图、成员负载条形图
- 项目时间线动态

**工程与体验**

- JWT 认证 + bcrypt 密码哈希，接口按项目成员鉴权
- 浅色 / 深色主题、响应式布局、空状态与加载状态
- 一键生成演示数据（4 位成员 / 3 个项目 / 28 个任务）
- Docker 镜像与 Render 蓝图，支持云平台部署

| 登录 | 任务详情 |
| --- | --- |
| ![登录](screenshots/login.png) | ![任务详情](screenshots/task.png) |

| 数据洞察 | 深色主题 |
| --- | --- |
| ![数据洞察](screenshots/dashboard.png) | ![深色主题](screenshots/board-dark.png) |

## 技术栈

| 层 | 技术 | 说明 |
| --- | --- | --- |
| 前端 | React 18、Vite 5、原生 CSS | 组件化 + CSS 变量主题，无重型 UI 依赖 |
| 前端实时 | socket.io-client | 项目房间、事件订阅、断线重连 |
| 后端 | Node.js 24、Express 4 | REST API、中间件鉴权、静态资源托管 |
| 实时 | Socket.IO 4 | WebSocket 优先，按项目隔离广播 |
| 数据库 | SQLite（`node:sqlite`） | 零外部依赖、WAL 模式、单文件持久化 |
| 认证 | jsonwebtoken + bcryptjs | 7 天有效期 Token，密码加盐哈希 |
| 上传 | multer | 单文件 ≤ 10MB，落盘存储 |
| 部署 | Docker / Render / 任意 Node 主机 | 单容器，数据卷持久化 |

> 数据库使用 Node.js 内置的 `node:sqlite`，因此**不需要安装任何原生模块**，但要求 **Node.js ≥ 22.5**（推荐 24）。

## 快速开始

```bash
# 1. 安装依赖（Node 24 + pnpm / npm 均可）
pnpm install

# 2. 生成演示数据（首次启动会自动执行）
pnpm seed

# 3. 启动开发环境（前端 5173 + 后端 5174）
pnpm dev
```

打开 <http://localhost:5173>。

生产模式：

```bash
pnpm build     # 构建前端到 dist/
pnpm start     # 启动服务，默认 http://localhost:5174
```

### 演示账号

| 邮箱 | 密码 | 角色 |
| --- | --- | --- |
| 729649458@qq.com | demo1234 | 产品负责人（管理员） |
| lin@flowboard.dev | demo1234 | 前端工程师 |
| su@flowboard.dev | demo1234 | UI 设计师 |
| zhou@flowboard.dev | demo1234 | 后端工程师 |

登录页点击「使用演示账号一键体验」即可直接进入。

> 演示模式：访问 `/?demo=1` 自动登录管理员并打开第一个项目；`&view=dashboard` / `&view=activity` 可直接进入对应视图，`&task=<任务ID>` 打开任务抽屉，`&theme=dark` 切换深色主题。

### 环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PORT` | `5174` | 服务端口 |
| `DATA_DIR` | `./data` | SQLite 与上传文件目录 |
| `JWT_SECRET` | 自动生成并落盘 | 生产环境请显式设置 |
| `NODE_ENV` | — | `production` 时托管 `dist/` |

## 目录结构

```text
flowboard/
├─ server/                # 后端（ESM）
│  ├─ index.js            # HTTP + Socket.IO 启动入口
│  ├─ app.js              # 路由、鉴权、业务逻辑
│  ├─ db.js               # SQLite 连接、建表、工具函数
│  ├─ auth.js             # 密码哈希 / JWT / 权限中间件
│  ├─ realtime.js         # 房间、在线状态、事件推送
│  └─ seed.js             # 演示数据
├─ src/                   # 前端（React）
│  ├─ App.jsx             # 会话、路由状态、实时订阅
│  ├─ api.js / socket.js  # 请求与实时连接封装
│  ├─ styles.css          # 设计系统与全部样式
│  └─ components/         # 登录、侧栏、看板、抽屉、仪表盘…
├─ scripts/
│  ├─ dev.mjs             # 同时启动前后端
│  ├─ test-realtime.mjs   # 实时链路冒烟测试
│  └─ package-submission.ps1  # 一键打包提交材料
├─ docs/                  # 实习报告、部署指南、演示脚本
├─ screenshots/           # 项目截图
├─ Dockerfile / docker-compose.yml / render.yaml
└─ vite.config.js
```

## 数据模型

11 张表，覆盖用户、项目、成员、看板列、任务、标签、评论、检查项、附件、通知与动态。

```text
users ──< project_members >── projects ──< columns ──< tasks
                                  │                     ├──< comments
                                  │                     ├──< checklist_items
                                  │                     ├──< attachments
                                  │                     └──< task_labels >── labels
                                  ├──< activities
                                  └──< notifications
```

| 表 | 关键字段 | 说明 |
| --- | --- | --- |
| `users` | name、email、password_hash、role | 用户与全局角色 |
| `projects` | name、key、color、owner_id | 项目 |
| `project_members` | project_id、user_id、role | 多对多成员关系 |
| `columns` | name、position、wip_limit | 看板列 |
| `tasks` | title、priority、assignee_id、due_date、position、completed_at | 任务 |
| `labels` / `task_labels` | name、color | 标签与关联 |
| `comments` | task_id、user_id、body | 评论 |
| `checklist_items` | text、done、position | 检查项 |
| `attachments` | filename、original_name、size | 附件 |
| `notifications` | type、title、read | 站内通知 |
| `activities` | action、detail | 项目动态 |

## API 概览

统一前缀 `/api`，除注册 / 登录 / 健康检查外均需 `Authorization: Bearer <token>`，并按项目成员身份校验。

| 方法 | 路径 | 功能 |
| --- | --- | --- |
| POST | `/auth/register`、`/auth/login` | 注册 / 登录 |
| GET | `/auth/me` | 当前用户 |
| GET | `/projects` | 我的项目（含进度与成员） |
| POST | `/projects` | 创建项目（自动初始化列与标签） |
| GET | `/projects/:id/board` | 看板数据（列、任务、成员、标签） |
| POST / PATCH / DELETE | `/projects/:id` | 项目详情 / 更新 / 删除 |
| POST / DELETE | `/projects/:id/members` | 邀请 / 移除成员 |
| GET | `/projects/:id/stats` | 统计数据与趋势 |
| GET | `/projects/:id/activity` | 项目动态 |
| POST | `/projects/:id/tasks` | 新建任务 |
| GET / PATCH / DELETE | `/tasks/:id` | 任务详情 / 更新 / 删除 |
| POST | `/tasks/:id/move` | 拖拽流转（目标列 + 序号） |
| POST / DELETE | `/tasks/:id/comments`、`/comments/:id` | 评论 |
| POST / PATCH / DELETE | `/tasks/:id/checklist`、`/checklist/:id` | 检查项 |
| POST / GET | `/tasks/:id/attachments`、`/attachments/:id/download` | 附件 |
| GET / POST | `/notifications`、`/notifications/read` | 通知与已读 |
| GET | `/search?q=` | 全局搜索 |
| GET | `/health` | 健康检查 |

### 实时事件

| 事件 | 方向 | 说明 |
| --- | --- | --- |
| `project:join` / `project:leave` | C → S | 加入 / 离开项目房间 |
| `presence` | S → C | 在线成员列表 |
| `task:created` / `task:updated` | S → C | 任务变更 |
| `comment:created` | S → C | 新评论 |
| `board:refresh` | S → C | 看板需要刷新（删除、流转等） |
| `notification` | S → C | 定向推送站内通知 |

## 测试

```bash
# 实时链路冒烟测试（登录 → 连接 → 加入房间 → 创建任务 → 校验事件）
node scripts/test-realtime.mjs
```

功能测试用例、接口测试记录与部署验证见 [docs/2220232674_张金鹏_软件工程二班_实习报告.docx](docs/2220232674_张金鹏_软件工程二班_实习报告.docx) 第五章。

## 部署

### 方式一：Docker（推荐，任意云主机）

```bash
docker compose up -d --build
# 访问 http://<服务器IP>:5174
```

数据保存在 `flowboard-data` 卷中；升级时重新构建镜像即可，数据不丢失。

### 方式二：Render（免费，自带域名）

1. 将仓库推送到 GitHub；
2. Render → **New → Blueprint**，选择仓库，自动读取 `render.yaml`；
3. 部署完成后获得 `https://<service>.onrender.com` 域名；
4. 在环境变量中确认 `JWT_SECRET` 已自动生成。

> 免费实例休眠后首次访问较慢；`/data` 持久盘需要付费实例，若不挂载磁盘，重新部署会重置示例数据（对课程演示影响不大）。

### 方式三：Railway / Fly.io / 阿里云轻量服务器

任意支持 Docker 或 Node 24 的平台均可：暴露 `5174` 端口，挂载 `/data` 持久卷，配置 `JWT_SECRET` 即可。

完整步骤与截图位说明见 [docs/部署指南.md](docs/部署指南.md)。

## 常见问题

**启动报 `node:sqlite` 相关错误？** 请升级到 Node.js 22.5+，推荐 24。

**端口被占用？** `PORT=6000 pnpm start`。

**如何重置数据？** `pnpm seed:force`（会清空数据库并重新生成演示数据）。

**上传的附件存在哪里？** `DATA_DIR/uploads`，数据库仅保存元信息。

## License

MIT
