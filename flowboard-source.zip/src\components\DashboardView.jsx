import React, { useEffect, useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, PRIORITY, Spinner, timeAgo } from './ui.jsx';
import { useToast } from './Toast.jsx';

const ACTION_TEXT = {
  'task.created': '创建了任务',
  'task.updated': '更新了任务',
  'task.moved': '流转了任务',
  'task.deleted': '删除了任务',
  'task.completed': '完成了任务',
  'comment.created': '评论了任务',
  'project.created': '创建了项目',
  'project.updated': '更新了项目',
  'member.added': '邀请了成员',
};

function TrendChart({ data }) {
  const max = Math.max(3, ...data.map((d) => d.count));
  const W = 720;
  const H = 220;
  const padL = 34;
  const padR = 16;
  const padT = 16;
  const padB = 30;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;
  const x = (i) => padL + (i * innerW) / Math.max(1, data.length - 1);
  const y = (v) => padT + innerH - (v / max) * innerH;
  const ticks = Array.from({ length: max + 1 }, (_, i) => max - i);
  const points = data.map((d, i) => [x(i), y(d.count)]);
  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const area = `${line} L${x(data.length - 1)},${padT + innerH} L${padL},${padT + innerH} Z`;

  return (
    <svg className="trend" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="近 14 天完成趋势">
      <defs>
        <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#6366f1" stopOpacity="0.01" />
        </linearGradient>
      </defs>
      {ticks.map((t) => (
        <g key={t}>
          <line
            x1={padL}
            x2={W - padR}
            y1={y(t)}
            y2={y(t)}
            stroke="currentColor"
            strokeOpacity="0.08"
            strokeDasharray="3 5"
          />
          <text x={padL - 8} y={y(t) + 4} textAnchor="end" className="axis-label">
            {t}
          </text>
        </g>
      ))}
      <path d={area} fill="url(#trendFill)" />
      <path d={line} fill="none" stroke="#6366f1" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) => (
        <g key={i}>
          <circle cx={p[0]} cy={p[1]} r="3.6" fill="#fff" stroke="#6366f1" strokeWidth="2" />
          {data[i].count > 0 && <title>{`${data[i].date}：完成 ${data[i].count} 个任务`}</title>}
        </g>
      ))}
      {data.map((d, i) =>
        i % 2 === 0 ? (
          <text key={d.date} x={x(i)} y={H - 8} textAnchor="middle" className="axis-label">
            {d.label}
          </text>
        ) : null
      )}
    </svg>
  );
}

function Donut({ byPriority }) {
  const total = Object.values(byPriority).reduce((a, b) => a + b, 0) || 1;
  const r = 54;
  const c = 2 * Math.PI * r;
  let offset = 0;
  const segs = Object.entries(PRIORITY).map(([key, p]) => {
    const value = byPriority[key] || 0;
    const len = (value / total) * c;
    const seg = { key, ...p, value, len, offset };
    offset += len;
    return seg;
  });
  return (
    <div className="donut-wrap">
      <svg viewBox="0 0 140 140" className="donut">
        <circle cx="70" cy="70" r={r} fill="none" stroke="currentColor" strokeOpacity="0.08" strokeWidth="14" />
        {segs.map((s) => (
          <circle
            key={s.key}
            cx="70"
            cy="70"
            r={r}
            fill="none"
            stroke={s.color}
            strokeWidth="14"
            strokeDasharray={`${s.len} ${c - s.len}`}
            strokeDashoffset={-s.offset}
            transform="rotate(-90 70 70)"
            strokeLinecap="butt"
          />
        ))}
        <text x="70" y="66" textAnchor="middle" className="donut-num">
          {total}
        </text>
        <text x="70" y="84" textAnchor="middle" className="donut-label">
          个任务
        </text>
      </svg>
      <ul className="donut-legend">
        {segs.map((s) => (
          <li key={s.key}>
            <span style={{ background: s.color }} />
            {s.label}
            <b>{s.value}</b>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function DashboardView({ projectId, onOpenTask }) {
  const [stats, setStats] = useState(null);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  useEffect(() => {
    let alive = true;
    setLoading(true);
    Promise.all([api(`/projects/${projectId}/stats`), api(`/projects/${projectId}/activity`)])
      .then(([s, a]) => {
        if (!alive) return;
        setStats(s);
        setActivity(a.activities);
      })
      .catch((err) => toast(err.message, 'error'))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [projectId]);

  if (loading || !stats) {
    return (
      <div className="page">
        <div className="loading-block">
          <Spinner size={20} /> 正在汇总项目数据…
        </div>
      </div>
    );
  }

  const { totals, trend, byPriority, workload } = stats;
  const maxLoad = Math.max(1, ...workload.map((w) => w.total));

  return (
    <div className="page dashboard">
      <div className="dash-grid">
        <div className="dash-card stat-big">
          <span className="stat-icon" style={{ '--c': '#6366f1' }}>
            <Icon name="grid" size={18} />
          </span>
          <div>
            <span>任务总数</span>
            <b>{totals.total}</b>
          </div>
          <em>覆盖全部 4 个列表</em>
        </div>
        <div className="dash-card stat-big">
          <span className="stat-icon" style={{ '--c': '#10b981' }}>
            <Icon name="check" size={18} />
          </span>
          <div>
            <span>已完成</span>
            <b>{totals.done}</b>
          </div>
          <em>完成率 {totals.completionRate}%</em>
        </div>
        <div className="dash-card stat-big">
          <span className="stat-icon" style={{ '--c': '#0ea5e9' }}>
            <Icon name="clock" size={18} />
          </span>
          <div>
            <span>进行中</span>
            <b>{totals.active}</b>
          </div>
          <em>平均周期 {totals.avgCycleDays} 天</em>
        </div>
        <div className="dash-card stat-big">
          <span className="stat-icon" style={{ '--c': '#ef4444' }}>
            <Icon name="alert" size={18} />
          </span>
          <div>
            <span>已逾期</span>
            <b>{totals.overdue}</b>
          </div>
          <em>{totals.overdue ? '需要尽快跟进' : '进度健康'}</em>
        </div>
      </div>

      <div className="dash-row">
        <section className="dash-card chart-card">
          <div className="card-head">
            <div>
              <h3>近 14 天完成趋势</h3>
              <p>每天完成的任务数，用于观察交付节奏</p>
            </div>
            <span className="pill">
              <Icon name="activity" size={13} /> 实时统计
            </span>
          </div>
          <TrendChart data={trend} />
        </section>

        <section className="dash-card donut-card">
          <div className="card-head">
            <div>
              <h3>优先级分布</h3>
              <p>紧急任务占比越低越健康</p>
            </div>
          </div>
          <Donut byPriority={byPriority} />
        </section>
      </div>

      <div className="dash-row">
        <section className="dash-card">
          <div className="card-head">
            <div>
              <h3>成员负载</h3>
              <p>当前各成员承担的任务数量</p>
            </div>
          </div>
          <ul className="workload">
            {workload.map((m) => (
              <li key={m.id}>
                <Avatar user={m} size={30} />
                <div className="workload-main">
                  <div className="workload-top">
                    <b>{m.name}</b>
                    <span>
                      {m.done}/{m.total} 已完成
                    </span>
                  </div>
                  <div className="workload-bar">
                    <span style={{ width: `${(m.total / maxLoad) * 100}%` }} />
                    <i style={{ width: `${(m.done / maxLoad) * 100}%` }} />
                  </div>
                </div>
                <span className="workload-num">{m.active}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="dash-card">
          <div className="card-head">
            <div>
              <h3>最近动态</h3>
              <p>团队在项目中的关键操作</p>
            </div>
          </div>
          <ul className="mini-activity">
            {activity.slice(0, 6).map((a) => (
              <li key={a.id} onClick={() => a.taskId && onOpenTask?.(a.taskId)}>
                <Avatar user={a.user} size={26} />
                <div>
                  <p>
                    <b>{a.user?.name || '系统'}</b> {ACTION_TEXT[a.action] || a.action}
                  </p>
                  <span>{a.detail}</span>
                </div>
                <time>{timeAgo(a.createdAt)}</time>
              </li>
            ))}
            {activity.length === 0 && <p className="muted small">暂无动态</p>}
          </ul>
        </section>
      </div>
    </div>
  );
}
