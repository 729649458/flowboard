import React from 'react';
import { Icon, Avatar } from './ui.jsx';

export default function Sidebar({ user, projects, activeProjectId, view, onHome, onSelectProject, onCreate, onLogout }) {
  return (
    <aside className="sidebar">
      <button className="sidebar-brand" onClick={onHome}>
        <span className="brand-mark">
          <span />
          <span />
          <span />
          <span />
        </span>
        <span className="brand-text">
          <b>FlowBoard</b>
          <em>团队协作平台</em>
        </span>
      </button>

      <nav className="sidebar-nav">
        <button className={`nav-item ${view === 'projects' ? 'active' : ''}`} onClick={onHome}>
          <Icon name="grid" size={17} />
          <span>工作台</span>
        </button>
      </nav>

      <div className="sidebar-section">
        <div className="sidebar-section-head">
          <span>我的项目</span>
          <button className="icon-btn tiny" onClick={onCreate} title="新建项目">
            <Icon name="plus" size={15} />
          </button>
        </div>
        <div className="project-list">
          {projects.map((p) => (
            <button
              key={p.id}
              className={`project-link ${activeProjectId === p.id ? 'active' : ''}`}
              onClick={() => onSelectProject(p.id)}
              title={p.name}
            >
              <span className="project-dot" style={{ background: p.color }} />
              <span className="project-link-name">{p.name}</span>
              <span className="project-link-count">{p.taskCount}</span>
            </button>
          ))}
          {projects.length === 0 && <p className="sidebar-empty">还没有项目，点击右上角 + 创建</p>}
        </div>
      </div>

      <div className="sidebar-tip">
        <Icon name="sparkles" size={16} />
        <div>
          <b>实时协作已开启</b>
          <span>团队成员的操作会即时同步</span>
        </div>
      </div>

      <div className="sidebar-user">
        <Avatar user={user} size={34} />
        <div className="sidebar-user-meta">
          <b>{user.name}</b>
          <span>{user.title || '团队成员'}</span>
        </div>
        <button className="icon-btn" onClick={onLogout} title="退出登录">
          <Icon name="logout" size={17} />
        </button>
      </div>
    </aside>
  );
}
