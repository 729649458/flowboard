import jwt from 'jsonwebtoken';
import { get, JWT_SECRET } from './db.js';

const presence = new Map(); // projectId -> Map<userId, { user, sockets }>

const brief = (u) => ({
  id: u.id,
  name: u.name,
  title: u.title,
  avatarColor: u.avatar_color,
});

function leavePresence(io, projectId, userId) {
  const map = presence.get(projectId);
  if (!map) return;
  const entry = map.get(userId);
  if (!entry) return;
  entry.sockets -= 1;
  if (entry.sockets <= 0) map.delete(userId);
  if (map.size === 0) presence.delete(projectId);
  io.to(`project:${projectId}`).emit('presence', {
    projectId,
    online: [...map.values()].map((e) => e.user),
  });
}

export function attachRealtime(io) {
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('unauthorized'));
      const payload = jwt.verify(token, JWT_SECRET);
      const user = get('SELECT * FROM users WHERE id = ?', payload.sub);
      if (!user) return next(new Error('unauthorized'));
      socket.data.user = user;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.data.user;
    socket.join(`user:${user.id}`);
    const joined = new Set();

    socket.on('project:join', (projectId) => {
      if (!projectId || joined.has(projectId)) return;
      const ok = get(
        'SELECT 1 AS ok FROM project_members WHERE project_id = ? AND user_id = ?',
        projectId,
        user.id
      );
      if (!ok) return;
      joined.add(projectId);
      socket.join(`project:${projectId}`);

      const map = presence.get(projectId) ?? new Map();
      presence.set(projectId, map);
      const entry = map.get(user.id) ?? { user: brief(user), sockets: 0 };
      entry.sockets += 1;
      map.set(user.id, entry);
      io.to(`project:${projectId}`).emit('presence', {
        projectId,
        online: [...map.values()].map((e) => e.user),
      });
    });

    socket.on('project:leave', (projectId) => {
      if (!joined.has(projectId)) return;
      joined.delete(projectId);
      socket.leave(`project:${projectId}`);
      leavePresence(io, projectId, user.id);
    });

    socket.on('disconnect', () => {
      for (const projectId of joined) leavePresence(io, projectId, user.id);
    });
  });
}
