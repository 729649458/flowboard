import React, { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, Modal, Spinner } from './ui.jsx';
import { useToast } from './Toast.jsx';

const PALETTE = ['#4f46e5', '#db2777', '#0891b2', '#059669', '#d97706', '#7c3aed', '#dc2626', '#2563eb'];

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return '夜深了';
  if (h < 11) return '早上好';
  if (h < 14) return '中午好';
  if (h < 18) return '下午好';
  return '晚上好';
}

export default function ProjectsView({ user, projects, openSignal = 0, onOpen, onReload }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', key: '', description: '', color: PALETTE[0] });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const handledSignal = useRef(0);
  const toast = useToast();

  useEffect(() => {
    if (openSignal > 0 && openSignal !== handledSignal.current) {
      handledSignal.current = openSignal;
      setOpen(true);
    }
  }, [openSignal]);

  const stats = useMemo(() => {
    const total = projects.reduce((a, p) => a + p.taskCount, 0);
    const done = projects.reduce((a, p) => a + p.doneCount, 0);
    return {
      total,
      done,
      active: total - done,
      rate: total ? Math.round((done / total) * 100) : 0,
      members: new Set(projects.flatMap((p) => (p.members || []).map((m) => m.id))).size,
    };
  }, [projects]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const data = await api('/projects', { method: 'POST', body: form });
      setOpen(false);
      setForm({ name: '', key: '', description: '', color: PALETTE[0] });
      toast('项目创建成功', 'success');
      await onReload();
      onOpen(data.project.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const today = new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' });

  return (
    <div className="page projects-page">
      <div className="page-head">
        <div>
          <p className="eyebrow">{today}</p>
          <h1>
            {greeting()}，{user.name}
          </h1>
          <p className="page-sub">这是你的工作台，今天也一起把想法变成交付。</p>
        </div>
        <button className="btn btn-primary" onClick={() => setOpen(true)}>
          <Icon name="plus" size={16} /> 新建项目
        </button>
      </div>

      <div className="stat-strip">
        <div className="stat-card">
          <span className="stat-icon" style={{ '--c': '#6366f1' }}>
            <Icon name="grid" size={18} />
          </span>
          <div>
            <b>{projects.length}</b>
            <span>进行中的项目</span>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon" style={{ '--c': '#0ea5e9' }}>
            <Icon name="board" size={18} />
          </span>
          <div>
            <b>{stats.active}</b>
            <span>待推进任务</span>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon" style={{ '--c': '#10b981' }}>
            <Icon name="check" size={18} />
          </span>
          <div>
            <b>{stats.done}</b>
            <span>已完成任务</span>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon" style={{ '--c': '#f59e0b' }}>
            <Icon name="target" size={18} />
          </span>
          <div>
            <b>{stats.rate}%</b>
            <span>整体完成率</span>
          </div>
        </div>
      </div>

      <div className="section-head">
        <h2>我的项目</h2>
        <span className="muted">共 {projects.length} 个</span>
      </div>

      <div className="project-grid">
        {projects.map((p) => {
          const rate = p.taskCount ? Math.round((p.doneCount / p.taskCount) * 100) : 0;
          return (
            <article
              key={p.id}
              className="project-card"
              style={{ '--pc': p.color }}
              onClick={() => onOpen(p.id)}
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && onOpen(p.id)}
            >
              <div className="project-card-top">
                <span className="project-key">{p.key}</span>
                <span className="project-members">
                  {(p.members || []).slice(0, 4).map((m) => (
                    <Avatar key={m.id} user={m} size={24} />
                  ))}
                  {p.memberCount > 4 && <span className="more-people">+{p.memberCount - 4}</span>}
                </span>
              </div>
              <h3>{p.name}</h3>
              <p className="project-desc">{p.description || '还没有项目描述'}</p>

              <div className="progress-row">
                <div className="progress">
                  <span style={{ width: `${rate}%` }} />
                </div>
                <b>{rate}%</b>
              </div>

              <div className="project-card-foot">
                <span>
                  <Icon name="check" size={13} /> {p.doneCount}/{p.taskCount} 已完成
                </span>
                <span>
                  <Icon name="users" size={13} /> {p.memberCount} 人
                </span>
              </div>
            </article>
          );
        })}

        <button className="project-card project-new" onClick={() => setOpen(true)}>
          <span className="new-plus">
            <Icon name="plus" size={20} />
          </span>
          <b>新建项目</b>
          <span>从空白看板开始，或邀请成员一起协作</span>
        </button>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} width={520}>
        <form onSubmit={submit} className="modal-form">
          <div className="modal-head">
            <h3>新建项目</h3>
            <button type="button" className="icon-btn" onClick={() => setOpen(false)}>
              <Icon name="x" size={18} />
            </button>
          </div>
          <p className="modal-sub">为项目取一个清晰的名字，团队会更容易达成共识。</p>

          <label className="field">
            <span>项目名称</span>
            <div className="input-wrap">
              <Icon name="board" size={16} />
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="例如：App 3.0 体验升级"
                maxLength={40}
                required
                autoFocus
              />
            </div>
          </label>

          <label className="field">
            <span>项目缩写</span>
            <div className="input-wrap">
              <Icon name="sparkles" size={16} />
              <input
                value={form.key}
                onChange={(e) => setForm({ ...form, key: e.target.value.toUpperCase().slice(0, 6) })}
                placeholder="例如：APP"
              />
            </div>
          </label>

          <label className="field">
            <span>项目描述</span>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="一句话说明这个项目要解决什么问题"
              rows={3}
              maxLength={500}
            />
          </label>

          <div className="field">
            <span>主题色</span>
            <div className="swatches">
              {PALETTE.map((c) => (
                <button
                  type="button"
                  key={c}
                  className={`swatch ${form.color === c ? 'active' : ''}`}
                  style={{ background: c }}
                  onClick={() => setForm({ ...form, color: c })}
                  aria-label={c}
                />
              ))}
            </div>
          </div>

          {error && <p className="form-error">{error}</p>}

          <div className="modal-foot">
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>
              取消
            </button>
            <button className="btn btn-primary" disabled={busy}>
              {busy && <Spinner size={15} />} 创建项目
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
