import React, { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';
import { Icon, Avatar, Spinner, timeAgo } from './ui.jsx';

const VIEW_LABEL = { board: '看板', dashboard: '数据洞察', activity: '项目动态' };

export default function Topbar({
  user,
  project,
  view,
  onHome,
  onOpenProject,
  onOpenTask,
  notifications,
  unread,
  onReadAll,
  onNotifyClick,
  theme,
  onToggleTheme,
}) {
  const [q, setQ] = useState('');
  const [result, setResult] = useState(null);
  const [searching, setSearching] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);
  const [openNotify, setOpenNotify] = useState(false);
  const boxRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const onDoc = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) {
        setOpenSearch(false);
        setOpenNotify(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault();
        inputRef.current?.focus();
      }
      if (e.key === 'Escape') {
        setOpenSearch(false);
        setOpenNotify(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    if (!q.trim()) {
      setResult(null);
      return;
    }
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const data = await api(`/search?q=${encodeURIComponent(q.trim())}`);
        setResult(data);
      } catch {
        setResult({ projects: [], tasks: [] });
      } finally {
        setSearching(false);
      }
    }, 220);
    return () => clearTimeout(timer);
  }, [q]);

  const unreadList = notifications.filter((n) => !n.read).length;

  return (
    <header className="topbar">
      <div className="crumbs">
        <button className="crumb-link" onClick={onHome}>
          工作台
        </button>
        {project && (
          <>
            <Icon name="chevron-right" size={14} className="crumb-sep" />
            <button className="crumb-link" onClick={() => onOpenProject(project.id, 'board')}>
              {project.name}
            </button>
            {view !== 'board' && (
              <>
                <Icon name="chevron-right" size={14} className="crumb-sep" />
                <span className="crumb-current">{VIEW_LABEL[view]}</span>
              </>
            )}
          </>
        )}
      </div>

      <div className="topbar-right" ref={boxRef}>
        <div className={`search ${openSearch ? 'open' : ''}`}>
          <Icon name="search" size={16} />
          <input
            ref={inputRef}
            value={q}
            placeholder="搜索任务、项目…"
            onChange={(e) => {
              setQ(e.target.value);
              setOpenSearch(true);
            }}
            onFocus={() => setOpenSearch(true)}
          />
          <kbd>/</kbd>

          {openSearch && (q.trim() || result) && (
            <div className="search-panel">
              {searching && (
                <div className="search-loading">
                  <Spinner size={14} /> 搜索中…
                </div>
              )}
              {!searching && result && result.projects.length === 0 && result.tasks.length === 0 && (
                <div className="search-empty">没有找到与「{q}」相关的内容</div>
              )}
              {result?.projects?.length > 0 && (
                <div className="search-group">
                  <p className="search-group-title">项目</p>
                  {result.projects.map((p) => (
                    <button
                      key={p.id}
                      className="search-item"
                      onClick={() => {
                        setOpenSearch(false);
                        setQ('');
                        onOpenProject(p.id);
                      }}
                    >
                      <span className="project-dot" style={{ background: p.color }} />
                      <span className="search-item-name">{p.name}</span>
                      <span className="search-item-meta">{p.key}</span>
                    </button>
                  ))}
                </div>
              )}
              {result?.tasks?.length > 0 && (
                <div className="search-group">
                  <p className="search-group-title">任务</p>
                  {result.tasks.map((t) => (
                    <button
                      key={t.id}
                      className="search-item"
                      onClick={() => {
                        setOpenSearch(false);
                        setQ('');
                        onOpenTask(t.projectId, t.id);
                      }}
                    >
                      <span className="search-item-icon" style={{ background: `${t.projectColor}18`, color: t.projectColor }}>
                        <Icon name="check" size={12} />
                      </span>
                      <span className="search-item-name">{t.title}</span>
                      <span className="search-item-meta">{t.projectName}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <button className="icon-btn" onClick={onToggleTheme} title={theme === 'dark' ? '切换浅色' : '切换深色'}>
          <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={18} />
        </button>

        <div className="notify-wrap">
          <button
            className={`icon-btn ${openNotify ? 'active' : ''}`}
            onClick={() => setOpenNotify((v) => !v)}
            title="通知"
          >
            <Icon name="bell" size={18} />
            {unread > 0 && <span className="badge-dot">{unread > 9 ? '9+' : unread}</span>}
          </button>

          {openNotify && (
            <div className="notify-panel">
              <div className="notify-head">
                <b>通知</b>
                {unreadList > 0 && (
                  <button className="link small" onClick={onReadAll}>
                    全部已读
                  </button>
                )}
              </div>
              <div className="notify-list">
                {notifications.length === 0 && <p className="notify-empty">暂无通知</p>}
                {notifications.map((n) => (
                  <button
                    key={n.id}
                    className={`notify-item ${n.read ? '' : 'unread'}`}
                    onClick={() => {
                      setOpenNotify(false);
                      onNotifyClick(n);
                    }}
                  >
                    <span className={`notify-type t-${n.type}`}>
                      <Icon
                        name={
                          n.type === 'assign'
                            ? 'target'
                            : n.type === 'comment' || n.type === 'mention'
                            ? 'message'
                            : n.type === 'invite'
                            ? 'users'
                            : 'bell'
                        }
                        size={14}
                      />
                    </span>
                    <span className="notify-body">
                      <b>{n.title}</b>
                      {n.body && <em>{n.body}</em>}
                      <small>{timeAgo(n.createdAt)}</small>
                    </span>
                    {!n.read && <span className="notify-dot" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="topbar-user">
          <Avatar user={user} size={32} />
          <div className="topbar-user-meta">
            <b>{user.name}</b>
            <span>{user.title || '成员'}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
