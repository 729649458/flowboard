import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, getToken, setToken } from './api.js';
import { connectSocket, disconnectSocket, getSocket } from './socket.js';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import ProjectsView from './components/ProjectsView.jsx';
import ProjectHeader from './components/ProjectHeader.jsx';
import BoardView from './components/BoardView.jsx';
import DashboardView from './components/DashboardView.jsx';
import ActivityView from './components/ActivityView.jsx';
import TaskDrawer from './components/TaskDrawer.jsx';
import Login from './components/Login.jsx';
import { useToast } from './components/Toast.jsx';

export default function App() {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [theme, setTheme] = useState(() => {
    const q = new URLSearchParams(window.location.search).get('theme');
    if (q === 'dark' || q === 'light') return q;
    return localStorage.getItem('flowboard.theme') || 'light';
  });
  const [projects, setProjects] = useState([]);
  const [board, setBoard] = useState(null);
  const [view, setView] = useState('projects');
  const [notifications, setNotifications] = useState([]);
  const [unread, setUnread] = useState(0);
  const [online, setOnline] = useState([]);
  const [openTaskId, setOpenTaskId] = useState(null);
  const [createSignal, setCreateSignal] = useState(0);
  const boardRef = useRef(null);
  const refreshTimer = useRef(null);
  const toast = useToast();

  boardRef.current = board;

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('flowboard.theme', theme);
  }, [theme]);

  const loadProjects = useCallback(async () => {
    const data = await api('/projects');
    setProjects(data.projects);
    return data.projects;
  }, []);

  const loadNotifications = useCallback(async () => {
    try {
      const data = await api('/notifications');
      setNotifications(data.notifications);
      setUnread(data.unread);
    } catch {
      /* ignore */
    }
  }, []);

  const refreshBoard = useCallback(async (projectId) => {
    if (!projectId) return;
    try {
      const data = await api(`/projects/${projectId}/board`);
      setBoard(data);
    } catch (err) {
      if (err.status === 403 || err.status === 404) {
        setView('projects');
        setBoard(null);
      }
    }
  }, []);

  const openProject = useCallback(
    async (projectId, nextView = 'board') => {
      try {
        const data = await api(`/projects/${projectId}/board`);
        setBoard(data);
        setView(nextView);
        setOnline([]);
        setOpenTaskId(null);
      } catch (err) {
        toast(err.message, 'error');
      }
    },
    [toast]
  );

  // 初始化：恢复会话 / Demo 自动登录
  useEffect(() => {
    let alive = true;
    (async () => {
      const params = new URLSearchParams(window.location.search);
      try {
        let me = null;
        if (getToken()) {
          try {
            me = (await api('/auth/me')).user;
          } catch {
            setToken(null);
          }
        }
        if (!me && params.get('demo') === '1') {
          const data = await api('/auth/login', {
            method: 'POST',
            body: { email: '729649458@qq.com', password: 'demo1234' },
          });
          setToken(data.token);
          me = data.user;
        }
        if (!alive) return;
        if (!me) {
          setBooting(false);
          return;
        }
        setUser(me);
        const list = await loadProjects();
        loadNotifications();
        if (!alive) return;
        setBooting(false);

        if (params.get('demo') === '1' && params.get('view') !== 'projects') {
          const pid = params.get('project') || list[0]?.id;
          if (pid) {
            await openProject(pid, params.get('view') || 'board');
            const taskId = params.get('task');
            if (taskId) setOpenTaskId(taskId);
          }
        }
      } catch {
        if (alive) setBooting(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [loadProjects, loadNotifications, openProject]);

  // 实时连接
  useEffect(() => {
    if (!user) return undefined;
    const socket = connectSocket();
    const onNotification = (n) => {
      setNotifications((prev) => [n, ...prev].slice(0, 40));
      setUnread((u) => u + 1);
      toast(n.title, 'info');
    };
    const onPresence = ({ projectId, online: list }) => {
      if (projectId === boardRef.current?.project?.id) setOnline(list);
    };
    const schedule = (projectId) => {
      if (projectId !== boardRef.current?.project?.id) return;
      clearTimeout(refreshTimer.current);
      refreshTimer.current = setTimeout(() => refreshBoard(projectId), 150);
    };
    const onBoard = ({ projectId }) => schedule(projectId);
    const onTask = ({ task }) => schedule(task.projectId);
    const onComment = ({ taskId }) => {
      const pid = boardRef.current?.project?.id;
      if (pid) schedule(pid);
      if (taskId) {
        /* 详情抽屉打开时由轮询式的刷新兜底 */
      }
    };
    socket.on('notification', onNotification);
    socket.on('presence', onPresence);
    socket.on('board:refresh', onBoard);
    socket.on('task:created', onTask);
    socket.on('task:updated', onTask);
    socket.on('comment:created', onComment);
    socket.on('connect', () => {
      if (boardRef.current) socket.emit('project:join', boardRef.current.project.id);
    });

    return () => {
      socket.off('notification', onNotification);
      socket.off('presence', onPresence);
      socket.off('board:refresh', onBoard);
      socket.off('task:created', onTask);
      socket.off('task:updated', onTask);
      socket.off('comment:created', onComment);
      disconnectSocket();
    };
  }, [user, refreshBoard, toast]);

  // 进入项目房间
  useEffect(() => {
    const socket = getSocket();
    const pid = board?.project?.id;
    if (!socket || !pid) return undefined;
    socket.emit('project:join', pid);
    return () => socket.emit('project:leave', pid);
  }, [board?.project?.id]);

  const logout = () => {
    setToken(null);
    disconnectSocket();
    setUser(null);
    setBoard(null);
    setProjects([]);
    setView('projects');
    setOpenTaskId(null);
    setNotifications([]);
    setUnread(0);
  };

  const onLogin = async (u) => {
    setUser(u);
    await loadProjects();
    loadNotifications();
  };

  const openTaskById = async (projectId, taskId) => {
    if (board?.project?.id !== projectId) {
      await openProject(projectId, 'board');
    }
    setOpenTaskId(taskId);
  };

  const markAllRead = async () => {
    try {
      await api('/notifications/read', { method: 'POST', body: {} });
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
      setUnread(0);
    } catch {
      /* ignore */
    }
  };

  const onNotifyClick = async (n) => {
    if (!n.read) {
      api('/notifications/read', { method: 'POST', body: { ids: [n.id] } }).catch(() => {});
      setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
      setUnread((u) => Math.max(0, u - 1));
    }
    if (n.projectId) {
      if (n.taskId) await openTaskById(n.projectId, n.taskId);
      else await openProject(n.projectId, 'board');
    }
  };

  useEffect(() => {
    if (view === 'projects' && user) loadProjects().catch(() => {});
  }, [view, user, loadProjects]);

  if (booting) {
    return (
      <div className="splash">
        <span className="brand-mark big">
          <span />
          <span />
          <span />
          <span />
        </span>
        <p>FlowBoard</p>
      </div>
    );
  }

  if (!user) return <Login onLogin={onLogin} />;

  return (
    <div className="app">
      <Sidebar
        user={user}
        projects={projects}
        activeProjectId={board?.project?.id}
        view={view}
        onHome={() => {
          setView('projects');
          setBoard(null);
        }}
        onSelectProject={(id) => openProject(id, 'board')}
        onCreate={() => {
          setView('projects');
          setBoard(null);
          setCreateSignal((s) => s + 1);
        }}
        onLogout={logout}
      />

      <div className="main">
        <Topbar
          user={user}
          project={view === 'projects' ? null : board?.project}
          view={view}
          onHome={() => {
            setView('projects');
            setBoard(null);
          }}
          onOpenProject={openProject}
          onOpenTask={openTaskById}
          notifications={notifications}
          unread={unread}
          onReadAll={markAllRead}
          onNotifyClick={onNotifyClick}
          theme={theme}
          onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        />

        <div className="content">
          {view === 'projects' && (
            <ProjectsView
              user={user}
              projects={projects}
              openSignal={createSignal}
              onOpen={(id) => openProject(id, 'board')}
              onReload={loadProjects}
            />
          )}

          {view !== 'projects' && board && (
            <>
              <ProjectHeader
                project={board.project}
                members={board.members}
                online={online}
                view={view}
                onChangeView={setView}
                onReload={() => refreshBoard(board.project.id)}
              />
              {view === 'board' && (
                <BoardView
                  board={board}
                  members={board.members}
                  currentUser={user}
                  onOpenTask={setOpenTaskId}
                  onRefresh={() => refreshBoard(board.project.id)}
                />
              )}
              {view === 'dashboard' && (
                <DashboardView projectId={board.project.id} onOpenTask={setOpenTaskId} />
              )}
              {view === 'activity' && <ActivityView projectId={board.project.id} onOpenTask={setOpenTaskId} />}
            </>
          )}

          {view !== 'projects' && !board && (
            <div className="page">
              <p className="muted">正在打开项目…</p>
            </div>
          )}
        </div>
      </div>

      {openTaskId && board && (
        <TaskDrawer
          taskId={openTaskId}
          projectId={board.project.id}
          members={board.members}
          labels={board.labels}
          columns={board.columns}
          currentUser={user}
          onClose={() => setOpenTaskId(null)}
          onChanged={() => refreshBoard(board.project.id)}
        />
      )}
    </div>
  );
}
