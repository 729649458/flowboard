import React, { useMemo, useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, PriorityFlag, formatDue, timeAgo } from './ui.jsx';
import { useToast } from './Toast.jsx';

const COLUMN_COLORS = {
  待办: '#94a3b8',
  进行中: '#3b82f6',
  待评审: '#f59e0b',
  已完成: '#10b981',
};

function TaskCard({ task, assignee, onOpen, onDragStart, dragging, dropBefore }) {
  const due = formatDue(task.dueDate);
  return (
    <article
      className={`task-card ${dragging ? 'dragging' : ''} ${dropBefore ? 'drop-before' : ''}`}
      draggable
      data-task-id={task.id}
      onDragStart={(e) => onDragStart(e, task)}
      onClick={() => onOpen(task.id)}
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onOpen(task.id)}
    >
      <span className={`prio-bar p-${task.priority}`} />
      {task.labels.length > 0 && (
        <div className="task-labels">
          {task.labels.slice(0, 3).map((l) => (
            <span key={l.id} className="label-chip" style={{ '--lc': l.color }}>
              {l.name}
            </span>
          ))}
        </div>
      )}
      <h4 className="task-title">{task.title}</h4>
      <div className="task-meta">
        <PriorityFlag priority={task.priority} />
        {task.completedAt ? (
          <span className="due due-done">
            <Icon name="check" size={12} /> 已完成
          </span>
        ) : (
          due && (
            <span className={`due due-${due.tone}`} title={due.date}>
              <Icon name="calendar" size={12} /> {due.text}
            </span>
          )
        )}
      </div>
      <div className="task-foot">
        <div className="task-counters">
          {task.checklist.total > 0 && (
            <span title="检查项">
              <Icon name="check" size={13} /> {task.checklist.done}/{task.checklist.total}
            </span>
          )}
          {task.commentCount > 0 && (
            <span title="评论">
              <Icon name="message" size={13} /> {task.commentCount}
            </span>
          )}
          {task.attachmentCount > 0 && (
            <span title="附件">
              <Icon name="paperclip" size={13} /> {task.attachmentCount}
            </span>
          )}
        </div>
        {assignee ? <Avatar user={assignee} size={24} /> : <span className="unassigned" title="未指派" />}
      </div>
    </article>
  );
}

export default function BoardView({ board, members, currentUser, onOpenTask, onRefresh }) {
  const [query, setQuery] = useState('');
  const [onlyMine, setOnlyMine] = useState(false);
  const [drag, setDrag] = useState(null);
  const [over, setOver] = useState(null);
  const [composer, setComposer] = useState(null);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const toast = useToast();

  const byId = useMemo(() => new Map(members.map((m) => [m.id, m])), [members]);

  const visibleTasks = (col) =>
    col.tasks.filter((t) => {
      if (onlyMine && t.assigneeId !== currentUser.id) return false;
      if (!query.trim()) return true;
      const q = query.trim().toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.labels.some((l) => l.name.toLowerCase().includes(q))
      );
    });

  const onDragStart = (e, task) => {
    setDrag({ taskId: task.id, from: task.columnId });
    e.dataTransfer.effectAllowed = 'move';
    try {
      e.dataTransfer.setData('text/plain', task.id);
    } catch {
      /* ignore */
    }
  };

  const onDragOverColumn = (e, col) => {
    e.preventDefault();
    const cards = [...e.currentTarget.querySelectorAll('[data-task-id]')];
    let index = cards.length;
    for (const el of cards) {
      const r = el.getBoundingClientRect();
      if (e.clientY < r.top + r.height / 2) {
        index = cards.indexOf(el);
        break;
      }
    }
    if (!over || over.columnId !== col.id || over.index !== index) {
      setOver({ columnId: col.id, index });
    }
  };

  const onDropColumn = async (e, col) => {
    e.preventDefault();
    const current = drag;
    const target = over && over.columnId === col.id ? over.index : col.tasks.length;
    setDrag(null);
    setOver(null);
    if (!current) return;
    let index = target;
    if (current.from === col.id) {
      const fromIdx = col.tasks.findIndex((t) => t.id === current.taskId);
      if (fromIdx > -1 && fromIdx < index) index -= 1;
    }
    try {
      await api(`/tasks/${current.taskId}/move`, {
        method: 'POST',
        body: { columnId: col.id, index },
      });
      onRefresh();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const addTask = async (colId) => {
    const title = draft.trim();
    if (!title || saving) return;
    setSaving(true);
    try {
      await api(`/projects/${board.project.id}/tasks`, {
        method: 'POST',
        body: { title, columnId: colId },
      });
      setDraft('');
      setComposer(null);
      toast('任务已创建', 'success');
      onRefresh();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const total = board.columns.reduce((a, c) => a + c.tasks.length, 0);

  return (
    <div className="board">
      <div className="board-toolbar">
        <div className="board-filter">
          <Icon name="search" size={15} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="在本项目中筛选任务…"
          />
        </div>
        <button className={`chip ${onlyMine ? 'active' : ''}`} onClick={() => setOnlyMine((v) => !v)}>
          <Avatar user={currentUser} size={18} /> 只看我的
        </button>
        <div className="board-meta">
          <span>
            <Icon name="board" size={14} /> {board.columns.length} 个列表
          </span>
          <span>
            <Icon name="check" size={14} /> {total} 个任务
          </span>
        </div>
      </div>

      <div className="board-columns">
        {board.columns.map((col, ci) => {
          const tasks = visibleTasks(col);
          const color = COLUMN_COLORS[col.name] || ['#94a3b8', '#3b82f6', '#8b5cf6', '#10b981'][ci % 4];
          const overWip = col.wipLimit && col.tasks.length >= col.wipLimit;
          return (
            <section
              key={col.id}
              className={`board-col ${over?.columnId === col.id ? 'drop-target' : ''}`}
              onDragOver={(e) => onDragOverColumn(e, col)}
              onDragLeave={(e) => {
                if (!e.currentTarget.contains(e.relatedTarget)) setOver(null);
              }}
              onDrop={(e) => onDropColumn(e, col)}
            >
              <header className="col-head">
                <span className="col-dot" style={{ background: color }} />
                <h3>{col.name}</h3>
                <span className="col-count">{tasks.length}</span>
                {col.wipLimit && (
                  <span className={`wip ${overWip ? 'over' : ''}`} title="WIP 限制">
                    WIP {col.tasks.length}/{col.wipLimit}
                  </span>
                )}
                <button
                  className="icon-btn tiny"
                  title="添加任务"
                  onClick={() => {
                    setComposer(col.id);
                    setDraft('');
                  }}
                >
                  <Icon name="plus" size={15} />
                </button>
              </header>

              <div className="col-body">
                {tasks.map((task, i) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    assignee={byId.get(task.assigneeId)}
                    onOpen={onOpenTask}
                    onDragStart={onDragStart}
                    dragging={drag?.taskId === task.id}
                    dropBefore={over?.columnId === col.id && over.index === i && drag?.taskId !== task.id}
                  />
                ))}

                {composer === col.id && (
                  <div className="composer">
                    <textarea
                      autoFocus
                      value={draft}
                      rows={2}
                      placeholder="输入任务标题，Enter 创建"
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          addTask(col.id);
                        }
                        if (e.key === 'Escape') setComposer(null);
                      }}
                    />
                    <div className="composer-foot">
                      <span>Enter 创建 · Esc 取消</span>
                      <button className="btn btn-primary tiny" disabled={saving || !draft.trim()} onClick={() => addTask(col.id)}>
                        创建
                      </button>
                    </div>
                  </div>
                )}

                {tasks.length === 0 && composer !== col.id && (
                  <button
                    className="col-empty"
                    onClick={() => {
                      setComposer(col.id);
                      setDraft('');
                    }}
                  >
                    <Icon name="plus" size={15} /> 添加第一个任务
                  </button>
                )}

                {tasks.length > 0 && composer !== col.id && (
                  <button
                    className="col-add"
                    onClick={() => {
                      setComposer(col.id);
                      setDraft('');
                    }}
                  >
                    <Icon name="plus" size={14} /> 添加任务
                  </button>
                )}

                {drag && over?.columnId === col.id && over.index >= tasks.length && (
                  <div className="drop-line end" />
                )}
              </div>
            </section>
          );
        })}
      </div>

      <p className="board-foot">
        共 {total} 个任务 · 最后同步于 {timeAgo(new Date().toISOString())} · 拖拽卡片可流转状态
      </p>
    </div>
  );
}
