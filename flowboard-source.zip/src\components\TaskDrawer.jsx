import React, { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, Modal, PRIORITY, Spinner, formatDue, timeAgo } from './ui.jsx';
import { useToast } from './Toast.jsx';

const fmtSize = (n) => (n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export default function TaskDrawer({ taskId, projectId, members, labels, columns, currentUser, onClose, onChanged }) {
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [descEditing, setDescEditing] = useState(false);
  const [comment, setComment] = useState('');
  const [newItem, setNewItem] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);
  const toast = useToast();

  useEffect(() => {
    let alive = true;
    setLoading(true);
    api(`/tasks/${taskId}`)
      .then(({ task }) => {
        if (!alive) return;
        setTask(task);
        setTitle(task.title);
        setDesc(task.description || '');
      })
      .catch((err) => toast(err.message, 'error'))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [taskId]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && !confirmDelete && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, confirmDelete]);

  const apply = async (body) => {
    const { task: updated } = await api(`/tasks/${taskId}`, { method: 'PATCH', body });
    setTask(updated);
    setTitle(updated.title);
    setDesc(updated.description || '');
    onChanged?.();
    return updated;
  };

  const saveTitle = async () => {
    if (!task || !title.trim() || title === task.title) return;
    try {
      await apply({ title: title.trim() });
      toast('标题已更新', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const saveDesc = async () => {
    if (!task) return;
    setDescEditing(false);
    if (desc === task.description) return;
    try {
      await apply({ description: desc });
      toast('描述已保存', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const setMeta = async (patch) => {
    try {
      await apply(patch);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const moveTo = async (columnId) => {
    try {
      await api(`/tasks/${taskId}/move`, { method: 'POST', body: { columnId, index: 9999 } });
      const { task: updated } = await api(`/tasks/${taskId}`);
      setTask(updated);
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const toggleLabel = async (labelId) => {
    const ids = task.labels.map((l) => l.id);
    const next = ids.includes(labelId) ? ids.filter((i) => i !== labelId) : [...ids, labelId];
    try {
      await apply({ labelIds: next });
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const addComment = async (e) => {
    e.preventDefault();
    if (!comment.trim() || saving) return;
    setSaving(true);
    try {
      const { comment: c } = await api(`/tasks/${taskId}/comments`, {
        method: 'POST',
        body: { body: comment.trim() },
      });
      setTask((t) => ({ ...t, comments: [...t.comments, c], commentCount: (t.commentCount || 0) + 1 }));
      setComment('');
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const removeComment = async (id) => {
    try {
      await api(`/comments/${id}`, { method: 'DELETE' });
      setTask((t) => ({ ...t, comments: t.comments.filter((c) => c.id !== id) }));
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const addItem = async (e) => {
    e.preventDefault();
    if (!newItem.trim()) return;
    try {
      const { task: updated } = await api(`/tasks/${taskId}/checklist`, {
        method: 'POST',
        body: { text: newItem.trim() },
      });
      setTask(updated);
      setNewItem('');
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const toggleItem = async (item) => {
    try {
      const { task: updated } = await api(`/checklist/${item.id}`, {
        method: 'PATCH',
        body: { done: !item.done },
      });
      setTask(updated);
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const removeItem = async (item) => {
    try {
      const { task: updated } = await api(`/checklist/${item.id}`, { method: 'DELETE' });
      setTask(updated);
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const upload = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const { attachment } = await api(`/tasks/${taskId}/attachments`, { method: 'POST', body: fd });
      setTask((t) => ({ ...t, attachments: [...t.attachments, attachment], attachmentCount: (t.attachmentCount || 0) + 1 }));
      toast('附件已上传', 'success');
      onChanged?.();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const removeTask = async () => {
    try {
      await api(`/tasks/${taskId}`, { method: 'DELETE' });
      toast('任务已删除', 'success');
      onChanged?.();
      onClose();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  if (loading || !task) {
    return (
      <div className="drawer-mask" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
        <aside className="drawer">
          <div className="drawer-loading">
            <Spinner size={22} /> 正在加载任务…
          </div>
        </aside>
      </div>
    );
  }

  const due = formatDue(task.dueDate);
  const doneCount = task.checklist.filter((c) => c.done).length;
  const checkRate = task.checklist.length ? Math.round((doneCount / task.checklist.length) * 100) : 0;

  return (
    <div className="drawer-mask" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="drawer" role="dialog" aria-modal="true">
        <header className="drawer-head">
          <div className="drawer-labels">
            {task.labels.map((l) => (
              <span key={l.id} className="label-chip" style={{ '--lc': l.color }}>
                {l.name}
              </span>
            ))}
            <span className="drawer-id">#{task.id.slice(-4).toUpperCase()}</span>
          </div>
          <button className="icon-btn" onClick={onClose} title="关闭">
            <Icon name="x" size={19} />
          </button>
        </header>

        <div className="drawer-body">
          <div className="drawer-main">
            <input
              className="task-title-input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={saveTitle}
              onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
            />

            <section className="drawer-section">
              <h4>任务描述</h4>
              {descEditing ? (
                <div className="desc-edit">
                  <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={5} autoFocus />
                  <div className="desc-actions">
                    <button className="btn btn-ghost tiny" onClick={() => { setDesc(task.description || ''); setDescEditing(false); }}>
                      取消
                    </button>
                    <button className="btn btn-primary tiny" onClick={saveDesc}>
                      保存
                    </button>
                  </div>
                </div>
              ) : (
                <p className={`desc-text ${task.description ? '' : 'placeholder'}`} onClick={() => setDescEditing(true)}>
                  {task.description || '点击添加更详细的描述、验收标准或背景信息…'}
                </p>
              )}
            </section>

            <section className="drawer-section">
              <div className="section-title-row">
                <h4>
                  检查项 <span className="muted">{doneCount}/{task.checklist.length}</span>
                </h4>
                <span className="pct">{checkRate}%</span>
              </div>
              <div className="check-progress">
                <span style={{ width: `${checkRate}%` }} />
              </div>
              <ul className="checklist">
                {task.checklist.map((item) => (
                  <li key={item.id} className={item.done ? 'done' : ''}>
                    <button className={`check-box ${item.done ? 'on' : ''}`} onClick={() => toggleItem(item)}>
                      {item.done && <Icon name="check" size={12} />}
                    </button>
                    <span>{item.text}</span>
                    <button className="icon-btn tiny hover-only" onClick={() => removeItem(item)} title="删除">
                      <Icon name="x" size={14} />
                    </button>
                  </li>
                ))}
              </ul>
              <form className="check-add" onSubmit={addItem}>
                <Icon name="plus" size={15} />
                <input value={newItem} onChange={(e) => setNewItem(e.target.value)} placeholder="添加检查项" />
              </form>
            </section>

            <section className="drawer-section">
              <div className="section-title-row">
                <h4>附件</h4>
                <button className="btn btn-ghost tiny" onClick={() => fileRef.current?.click()} disabled={uploading}>
                  {uploading ? <Spinner size={13} /> : <Icon name="upload" size={14} />} 上传
                </button>
              </div>
              <input
                ref={fileRef}
                type="file"
                hidden
                onChange={(e) => upload(e.target.files?.[0])}
              />
              {task.attachments.length === 0 ? (
                <p className="muted small">支持图片、文档、压缩包，单个文件不超过 10MB。</p>
              ) : (
                <ul className="attachments">
                  {task.attachments.map((a) => (
                    <li key={a.id}>
                      <span className="file-ico">
                        <Icon name="paperclip" size={15} />
                      </span>
                      <a href={a.url} target="_blank" rel="noreferrer">
                        {a.name}
                      </a>
                      <span className="muted">{fmtSize(a.size)}</span>
                      <a className="icon-btn tiny" href={a.url} download title="下载">
                        <Icon name="download" size={15} />
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="drawer-section">
              <h4>
                评论 <span className="muted">{task.comments.length}</span>
              </h4>
              <ul className="comments">
                {task.comments.map((c) => (
                  <li key={c.id}>
                    <Avatar user={c.user} size={30} />
                    <div className="comment-body">
                      <div className="comment-head">
                        <b>{c.user.name}</b>
                        <span>{timeAgo(c.createdAt)}</span>
                        {c.user.id === currentUser.id && (
                          <button className="icon-btn tiny hover-only" onClick={() => removeComment(c.id)} title="删除评论">
                            <Icon name="trash" size={13} />
                          </button>
                        )}
                      </div>
                      <p>{c.body}</p>
                    </div>
                  </li>
                ))}
                {task.comments.length === 0 && <p className="muted small">还没有评论，说点什么吧。</p>}
              </ul>
              <form className="comment-form" onSubmit={addComment}>
                <Avatar user={currentUser} size={30} />
                <div className="comment-input">
                  <textarea
                    rows={2}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="写下你的想法，Enter 发送，Shift + Enter 换行"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        addComment(e);
                      }
                    }}
                  />
                  <button className="btn btn-primary tiny" disabled={!comment.trim() || saving}>
                    发送
                  </button>
                </div>
              </form>
            </section>
          </div>

          <aside className="drawer-side">
            <div className="side-block">
              <h5>状态</h5>
              <select value={task.columnId} onChange={(e) => moveTo(e.target.value)}>
                {columns.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="side-block">
              <h5>指派给</h5>
              <select
                value={task.assigneeId || ''}
                onChange={(e) => setMeta({ assigneeId: e.target.value || null })}
              >
                <option value="">未指派</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="side-block">
              <h5>优先级</h5>
              <div className="priority-picker">
                {Object.entries(PRIORITY).map(([key, p]) => (
                  <button
                    key={key}
                    className={`prio-btn ${task.priority === key ? 'active' : ''}`}
                    style={{ '--pc': p.color }}
                    onClick={() => setMeta({ priority: key })}
                  >
                    <span /> {p.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="side-block">
              <h5>截止日期</h5>
              <input
                type="date"
                value={task.dueDate || ''}
                onChange={(e) => setMeta({ dueDate: e.target.value || null })}
              />
              {due && <p className={`due-hint tone-${due.tone}`}>{due.text}</p>}
            </div>

            <div className="side-block">
              <h5>标签</h5>
              <div className="label-picker">
                {labels.map((l) => (
                  <button
                    key={l.id}
                    className={`label-chip pick ${task.labels.some((x) => x.id === l.id) ? 'on' : ''}`}
                    style={{ '--lc': l.color }}
                    onClick={() => toggleLabel(l.id)}
                  >
                    {l.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="side-block side-meta">
              <div>
                <span>创建者</span>
                <b>{task.reporter?.name || '—'}</b>
              </div>
              <div>
                <span>创建时间</span>
                <b>{timeAgo(task.createdAt)}</b>
              </div>
              <div>
                <span>最近更新</span>
                <b>{timeAgo(task.updatedAt)}</b>
              </div>
            </div>

            <button className="btn btn-danger-ghost" onClick={() => setConfirmDelete(true)}>
              <Icon name="trash" size={15} /> 删除任务
            </button>
          </aside>
        </div>
      </aside>

      <Modal open={confirmDelete} onClose={() => setConfirmDelete(false)} width={400}>
        <div className="modal-form">
          <div className="modal-head">
            <h3>删除任务？</h3>
          </div>
          <p className="modal-sub">「{task.title}」及其评论、附件都会被移除，此操作不可撤销。</p>
          <div className="modal-foot">
            <button className="btn btn-ghost" onClick={() => setConfirmDelete(false)}>
              取消
            </button>
            <button className="btn btn-danger" onClick={removeTask}>
              确认删除
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
