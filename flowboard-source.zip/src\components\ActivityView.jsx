import React, { useEffect, useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, Spinner, timeAgo } from './ui.jsx';
import { useToast } from './Toast.jsx';

const ACTION_TEXT = {
  'task.created': '创建了任务',
  'task.updated': '更新了任务',
  'task.moved': '流转了任务',
  'task.deleted': '删除了任务',
  'task.completed': '完成了任务',
  'comment.created': '评论了任务',
  'project.created': '创建了项目',
  'project.updated': '更新了项目',
  'member.added': '邀请了成员',
};

function dayLabel(iso) {
  const d = new Date(iso);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const that = new Date(d);
  that.setHours(0, 0, 0, 0);
  const diff = Math.round((today - that) / 86400000);
  if (diff === 0) return '今天';
  if (diff === 1) return '昨天';
  return d.toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' });
}

export default function ActivityView({ projectId, onOpenTask }) {
  const [items, setItems] = useState(null);
  const toast = useToast();

  useEffect(() => {
    let alive = true;
    setItems(null);
    api(`/projects/${projectId}/activity`)
      .then((d) => alive && setItems(d.activities))
      .catch((err) => toast(err.message, 'error'));
    return () => {
      alive = false;
    };
  }, [projectId]);

  if (!items) {
    return (
      <div className="page">
        <div className="loading-block">
          <Spinner size={20} /> 正在加载项目动态…
        </div>
      </div>
    );
  }

  const groups = [];
  for (const item of items) {
    const label = dayLabel(item.createdAt);
    let g = groups.find((x) => x.label === label);
    if (!g) {
      g = { label, items: [] };
      groups.push(g);
    }
    g.items.push(item);
  }

  return (
    <div className="page activity-page">
      <div className="activity-card">
        <div className="card-head">
          <div>
            <h3>项目时间线</h3>
            <p>记录团队在项目中的每一次推进与讨论</p>
          </div>
          <span className="pill">
            <Icon name="activity" size={13} /> {items.length} 条动态
          </span>
        </div>

        {items.length === 0 && <p className="muted">还没有动态，创建一个任务试试。</p>}

        {groups.map((g) => (
          <div className="timeline-group" key={g.label}>
            <p className="timeline-day">{g.label}</p>
            <ul className="timeline">
              {g.items.map((a) => (
                <li key={a.id} className={a.taskId ? 'clickable' : ''} onClick={() => a.taskId && onOpenTask?.(a.taskId)}>
                  <div className="timeline-avatar">
                    <Avatar user={a.user} size={30} />
                  </div>
                  <div className="timeline-body">
                    <p>
                      <b>{a.user?.name || '系统'}</b> {ACTION_TEXT[a.action] || a.action}
                    </p>
                    {a.detail && <span className="timeline-detail">{a.detail}</span>}
                  </div>
                  <time>{timeAgo(a.createdAt)}</time>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
