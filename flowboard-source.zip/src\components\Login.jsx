import React, { useState } from 'react';
import { api, setToken } from '../api.js';
import { Icon, Spinner } from './ui.jsx';

export default function Login({ onLogin }) {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const path = mode === 'login' ? '/auth/login' : '/auth/register';
      const payload =
        mode === 'login'
          ? { email: form.email, password: form.password }
          : { name: form.name, email: form.email, password: form.password };
      const data = await api(path, { method: 'POST', body: payload });
      setToken(data.token);
      onLogin(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const demo = async () => {
    setError('');
    setBusy(true);
    try {
      const data = await api('/auth/login', {
        method: 'POST',
        body: { email: '729649458@qq.com', password: 'demo1234' },
      });
      setToken(data.token);
      onLogin(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <aside className="login-hero">
        <div className="login-brand">
          <span className="brand-mark">
            <span />
            <span />
            <span />
            <span />
          </span>
          <span className="brand-name">FlowBoard</span>
        </div>

        <div className="hero-copy">
          <p className="hero-eyebrow">
            <Icon name="zap" size={14} /> 实时协作 · 让交付更确定
          </p>
          <h1>
            让团队协作
            <br />
            像流水一样顺畅
          </h1>
          <p className="hero-sub">
            需求、任务、评审与交付在同一条河流里流转。多端实时同步，进度一目了然，把时间留给真正重要的事。
          </p>
          <ul className="hero-points">
            <li>
              <Icon name="grid" size={16} /> 可视化看板与拖拽流转
            </li>
            <li>
              <Icon name="activity" size={16} /> 多人实时同步与在线状态
            </li>
            <li>
              <Icon name="chart" size={16} /> 交付趋势与成员负载洞察
            </li>
          </ul>
        </div>

        <div className="hero-preview" aria-hidden="true">
          {[
            ['待办', ['品牌视觉走查', '接口联调']],
            ['进行中', ['看板拖拽重构', '实时同步']],
            ['已完成', ['需求评审']],
          ].map(([title, cards], i) => (
            <div className="mini-col" key={title} style={{ '--d': `${i * 70}ms` }}>
              <div className="mini-col-title">
                <span>{title}</span>
                <b>{cards.length}</b>
              </div>
              {cards.map((c) => (
                <div className="mini-card" key={c}>
                  <span className={`mini-dot d${i}`} />
                  {c}
                </div>
              ))}
            </div>
          ))}
        </div>

        <p className="hero-foot">FlowBoard 2.0 · 为小而美的团队打造</p>
      </aside>

      <main className="login-panel">
        <div className="login-box">
          <h2>{mode === 'login' ? '欢迎回来' : '创建你的账号'}</h2>
          <p className="login-sub">
            {mode === 'login' ? '登录后继续推进你的项目' : '30 秒完成注册，立即开始协作'}
          </p>

          <form onSubmit={submit} className="login-form">
            {mode === 'register' && (
              <label className="field">
                <span>昵称</span>
                <div className="input-wrap">
                  <Icon name="users" size={16} />
                  <input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="你的名字"
                    autoComplete="name"
                    required
                  />
                </div>
              </label>
            )}
            <label className="field">
              <span>邮箱</span>
              <div className="input-wrap">
                <Icon name="mail" size={16} />
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@company.com"
                  autoComplete="email"
                  required
                />
              </div>
            </label>
            <label className="field">
              <span>密码</span>
              <div className="input-wrap">
                <Icon name="lock" size={16} />
                <input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="至少 6 位字符"
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  minLength={6}
                  required
                />
              </div>
            </label>

            {error && (
              <p className="form-error">
                <Icon name="alert" size={14} /> {error}
              </p>
            )}

            <button className="btn btn-primary btn-block" disabled={busy}>
              {busy ? <Spinner size={16} /> : null}
              {mode === 'login' ? '登录' : '注册并进入'}
            </button>
          </form>

          <div className="login-divider">
            <span>或者</span>
          </div>

          <button className="btn btn-ghost btn-block" onClick={demo} disabled={busy}>
            <Icon name="sparkles" size={16} /> 使用演示账号一键体验
          </button>

          <p className="login-switch">
            {mode === 'login' ? '还没有账号？' : '已有账号？'}
            <button
              className="link"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setError('');
              }}
            >
              {mode === 'login' ? '立即注册' : '去登录'}
            </button>
          </p>

          <p className="login-hint">演示账号：729649458@qq.com / demo1234</p>
        </div>
      </main>
    </div>
  );
}
