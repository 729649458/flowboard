import React, { useState } from 'react';
import { api } from '../api.js';
import { Avatar, Icon, Modal, Spinner } from './ui.jsx';
import { useToast } from './Toast.jsx';

const TABS = [
  { key: 'board', label: '看板', icon: 'board' },
  { key: 'dashboard', label: '数据洞察', icon: 'chart' },
  { key: 'activity', label: '项目动态', icon: 'activity' },
];

export default function ProjectHeader({ project, members, online, view, onChangeView, onReload }) {
  const [inviteOpen, setInviteOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const toast = useToast();

  const onlineIds = new Set((online || []).map((u) => u.id));

  const invite = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api(`/projects/${project.id}/members`, { method: 'POST', body: { email } });
      toast('成员已加入项目', 'success');
      setEmail('');
      setInviteOpen(false);
      onReload();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="project-header">
      <div className="project-header-main">
        <div className="project-badge" style={{ '--pc': project.color }}>
          {project.key}
        </div>
        <div className="project-title">
          <h1>{project.name}</h1>
          <p>{project.description || '暂无项目描述'}</p>
        </div>
        <div className="project-header-actions">
          <div className="member-stack" title={`${members.length} 位成员`}>
            {members.slice(0, 5).map((m) => (
              <span key={m.id} className={`member-av ${onlineIds.has(m.id) ? 'online' : ''}`}>
                <Avatar user={m} size={28} />
              </span>
            ))}
            {members.length > 5 && <span className="member-more">+{members.length - 5}</span>}
          </div>
          {online?.length > 0 && (
            <span className="presence">
              <span className="presence-dot" /> {online.length} 人在线
            </span>
          )}
          <button className="btn btn-ghost small" onClick={() => setInviteOpen(true)}>
            <Icon name="users" size={15} /> 邀请成员
          </button>
        </div>
      </div>

      <div className="project-tabs">
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`tab ${view === t.key ? 'active' : ''}`}
            onClick={() => onChangeView(t.key)}
          >
            <Icon name={t.icon} size={15} /> {t.label}
          </button>
        ))}
      </div>

      <Modal open={inviteOpen} onClose={() => setInviteOpen(false)} width={460}>
        <form onSubmit={invite} className="modal-form">
          <div className="modal-head">
            <h3>邀请成员加入</h3>
            <button type="button" className="icon-btn" onClick={() => setInviteOpen(false)}>
              <Icon name="x" size={18} />
            </button>
          </div>
          <p className="modal-sub">输入成员注册邮箱，对方会收到站内通知。</p>
          <label className="field">
            <span>成员邮箱</span>
            <div className="input-wrap">
              <Icon name="mail" size={16} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="teammate@company.com"
                required
                autoFocus
              />
            </div>
          </label>
          <p className="field-hint">体验账号：lin@flowboard.dev、su@flowboard.dev、zhou@flowboard.dev</p>
          {error && <p className="form-error">{error}</p>}
          <div className="modal-foot">
            <button type="button" className="btn btn-ghost" onClick={() => setInviteOpen(false)}>
              取消
            </button>
            <button className="btn btn-primary" disabled={busy}>
              {busy && <Spinner size={15} />} 发送邀请
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
