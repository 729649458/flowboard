(function () {
  if (window.__imageGrabInjected) return;
  window.__imageGrabInjected = true;

  const btn = document.createElement("button");
  btn.id = "imagegrab-btn";
  btn.textContent = "获取图片";
  btn.title = "提取当前页面所有商品图片";
  document.documentElement.appendChild(btn);

  const toast = document.createElement("div");
  toast.id = "imagegrab-toast";
  document.documentElement.appendChild(toast);

  function showToast(text) {
    toast.textContent = text;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function bestFromSrcset(srcset) {
    if (!srcset) return "";
    return srcset
      .split(",")
      .map((part) => part.trim().split(/\s+/))
      .filter((p) => p[0])
      .sort((a, b) => (parseFloat(b[1]) || 0) - (parseFloat(a[1]) || 0))[0][0];
  }

  function collect() {
    const found = new Map();
    const add = (url, w, h) => {
      if (!url) return;
      url = url.trim();
      if (!/^(https?:|data:image\/)/i.test(url)) return;
      if (url.startsWith("data:") && url.length < 200) return;
      if (w && h && (w < 100 || h < 100)) return;
      if (!found.has(url)) found.set(url, { url, width: w || 0, height: h || 0 });
    };

    document.querySelectorAll("img").forEach((img) => {
      const w = img.naturalWidth || img.width;
      const h = img.naturalHeight || img.height;
      add(img.currentSrc || img.src, w, h);
      add(img.getAttribute("data-src"), w, h);
      add(img.getAttribute("data-lazy-src"), w, h);
      add(bestFromSrcset(img.getAttribute("srcset")), w, h);
    });

    document.querySelectorAll("*").forEach((el) => {
      const bg = getComputedStyle(el).backgroundImage;
      if (bg && bg !== "none") {
        const m = bg.match(/url\(["']?(.*?)["']?\)/);
        if (m) add(m[1], 0, 0);
      }
    });

    return [...found.values()];
  }

  btn.addEventListener("click", () => {
    const images = collect();
    if (!images.length) {
      showToast("没有找到可下载的商品图");
      return;
    }
    showToast(`已提取 ${images.length} 张图片`);
    chrome.runtime.sendMessage({ type: "OPEN_GALLERY", images });
  });
})();
