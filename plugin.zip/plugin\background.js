chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "OPEN_GALLERY") {
    chrome.storage.local.set({ imageGrabImages: message.images || [] }, () => {
      chrome.tabs.create({ url: chrome.runtime.getURL("gallery.html") });
    });
    sendResponse({ ok: true });
    return true;
  }
  return false;
});
